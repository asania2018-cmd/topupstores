require('dotenv').config();
const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const path = require('path');
const fileUpload = require('express-fileupload');
const fs = require('fs');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

const app = express();
const PORT = process.env.PORT || 3000;

// Ensure data directories exist
['data', 'data/products', 'data/db', 'data/bots'].forEach(d => {
  const full = path.join(__dirname, d);
  if (!fs.existsSync(full)) fs.mkdirSync(full, { recursive: true });
});

// Init default config
const cfgPath = path.join(__dirname, 'data/config.json');
if (!fs.existsSync(cfgPath)) {
  const { getDefaultConfig } = require('./lib/pricing');
  fs.writeFileSync(cfgPath, JSON.stringify(getDefaultConfig(), null, 2));
}

// Init banners.json
const bannersPath = path.join(__dirname, 'data/banners.json');
if (!fs.existsSync(bannersPath)) {
  fs.writeFileSync(bannersPath, JSON.stringify([
    { id: 'default1', title: 'Top Up Game Favorit!', subtitle: 'Harga terbaik, proses instan 24/7', link: '/topup', color_from: '#0d2b6b', color_to: '#1d4ed8', image_url: '', active: true, order: 1 }
  ], null, 2));
}

// Init flashsale.json
const flashsalePath = path.join(__dirname, 'data/flashsale.json');
if (!fs.existsSync(flashsalePath)) {
  fs.writeFileSync(flashsalePath, JSON.stringify([], null, 2));
}

// Init announcements.json
const annPath = path.join(__dirname, 'data/announcements.json');
if (!fs.existsSync(annPath)) {
  fs.writeFileSync(annPath, JSON.stringify([], null, 2));
}

// Init popups.json
const popupsPath = path.join(__dirname, 'data/popups.json');
if (!fs.existsSync(popupsPath)) {
  fs.writeFileSync(popupsPath, JSON.stringify([], null, 2));
}

// Init informasi.json
const informasiPath = path.join(__dirname, 'data/informasi.json');
if (!fs.existsSync(informasiPath)) {
  fs.writeFileSync(informasiPath, JSON.stringify([], null, 2));
}

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(expressLayouts);
app.set('layout', 'layout');

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(fileUpload({ limits: { fileSize: 5 * 1024 * 1024 } }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'h2h-secret-key-change-this',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

// Passport
app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser(async (id, done) => {
  try {
    const db = require('./lib/github-db');
    const user = await db.findUser({ id });
    if (!user) return done(null, false);
    const { password: _, ...safe } = user;
    done(null, safe);
  } catch (e) { done(e, null); }
});

const { getConfig: _getConfigForGoogle } = require('./lib/pricing');
const _googleCfg = _getConfigForGoogle().integrations || {};
const _googleClientId     = process.env.GOOGLE_CLIENT_ID     || _googleCfg.google_client_id     || '';
const _googleClientSecret = process.env.GOOGLE_CLIENT_SECRET || _googleCfg.google_client_secret || '';

if (_googleClientId && _googleClientSecret) {
  const db = require('./lib/github-db');
  const { generateApiKey } = require('./lib/auth');
  const { v4: uuidv4 } = require('uuid');

  passport.use(new GoogleStrategy({
    clientID:     _googleClientId,
    clientSecret: _googleClientSecret,
    callbackURL:  (process.env.SITE_URL || `http://localhost:${PORT}`) + '/auth/google/callback'
  }, async (accessToken, refreshToken, profile, done) => {
    try {
      const email     = profile.emails?.[0]?.value;
      const google_id = profile.id;
      if (!email) return done(null, false);

      // Try find by google_id first
      let user = await db.findUser({ google_id });
      if (!user) {
        // Try find by email
        user = await db.findUser({ email });
        if (user) {
          // Link Google to existing account
          await db.updateUser(user.id, { google_id, email_verified: true });
          user = await db.findUser({ id: user.id });
        } else {
          // Create new user
          const { users, sha } = await db.getUsers();
          let base = (profile.displayName || email.split('@')[0]).replace(/\s+/g, '_').toLowerCase();
          let username = base;
          let n = 1;
          while (users.find(u => u.username === username)) { username = base + n++; }
          const newUser = {
            id: uuidv4(),
            username,
            email,
            password: null,
            role: 'regular',
            google_id,
            apikey: generateApiKey(),
            balance: 0,
            email_verified: true,
            verify_token: null,
            verify_token_expires: null,
            twofa_enabled: false,
            twofa_otp: null,
            twofa_otp_expires: null,
            reset_token: null,
            reset_token_expires: null,
            read_announcements: [],
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          };
          users.push(newUser);
          await db.saveUsers(users, sha);
          user = newUser;
        }
      }
      const { password: _, ...safe } = user;
      // Set session manually for passport
      done(null, safe);
    } catch (e) { done(e, null); }
  }));
}

// After passport auth, also set req.session.user
app.use((req, res, next) => {
  if (req.isAuthenticated && req.isAuthenticated() && req.user && !req.session.user) {
    req.session.user = req.user;
  }
  next();
});

// Global template vars
const { getConfig: getSiteConfig } = require('./lib/pricing');
app.use((req, res, next) => {
  const cfg = getSiteConfig();
  const branding = cfg.branding || {};
  res.locals.siteName    = branding.site_name || process.env.SITE_NAME || 'H2H TopUp';
  res.locals.siteUrl     = process.env.SITE_URL  || `http://localhost:${PORT}`;
  res.locals.currentPath = req.path;
  res.locals.bodyClass   = req.path.startsWith('/admin') ? 'admin-body' : '';
  res.locals.user        = req.session?.user || null;
  res.locals.title       = '';
  res.locals.extraHead   = '';
  res.locals.extraScript = '';
  res.locals.siteConfig  = cfg;
  try {
    const allPopups = JSON.parse(fs.readFileSync(popupsPath, 'utf-8'));
    res.locals.sitePopups = allPopups.filter(p => p.active);
  } catch { res.locals.sitePopups = []; }
  next();
});

// Routes
app.use('/', require('./routes/auth'));
app.use('/', require('./routes/web'));
app.use('/admin', require('./routes/admin'));
app.use('/api', require('./routes/api'));
app.use('/', require('./routes/deposit'));

// 404
app.use((req, res) => {
  if (req.path.startsWith('/api')) return res.status(404).json({ status: false, message: 'Endpoint tidak ditemukan' });
  res.status(404).render('404', { user: req.session?.user || null });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err);
  if (req.path.startsWith('/api')) return res.status(500).json({ status: false, message: err.message });
  // Admin pages: redirect to admin dashboard with error message
  if (req.path.startsWith('/admin')) {
    return res.redirect('/admin?error=' + encodeURIComponent(err.message || 'Terjadi kesalahan server'));
  }
  try {
    res.status(500).render('404', { user: req.session?.user || null, title: 'Server Error' });
  } catch (_) {
    res.status(500).send('<h1>500 - Server Error</h1><p>' + (err.message || '') + '</p>');
  }
});

async function ensureAdmin() {
  try {
    const db = require('./lib/github-db');
    const { createUser } = require('./lib/auth');
    const admin = await db.findUser({ username: process.env.ADMIN_USERNAME || 'admin' });
    if (!admin) {
      await createUser({
        username: process.env.ADMIN_USERNAME || 'admin',
        email: 'admin@h2hapi.local',
        password: process.env.ADMIN_PASSWORD || 'admin123',
        role: 'admin',
        email_verified: true
      });
      console.log('Admin user created');
    } else if (!admin.email_verified) {
      await db.updateUser(admin.id, { email_verified: true });
    }
  } catch (e) {
    console.log('Admin check skipped (GitHub DB not configured):', e.message);
  }
}

app.listen(PORT, () => {
  console.log(`\nH2H TopUp Server — port ${PORT}`);
  console.log(`Docs: http://localhost:${PORT}/docs`);
  console.log(`Admin: http://localhost:${PORT}/admin\n`);
  ensureAdmin();
  startExpiryJob();
  startBotManager();
});

// Auto-mark expired QRIS orders & deposits setiap 3 menit
function startExpiryJob() {
  async function runExpiry() {
    try {
      const dbLib = require('./lib/github-db');
      const now = new Date();

      // Deposits
      try {
        const { deposits } = await dbLib.getDeposits();
        const expired = (deposits || []).filter(d =>
          d.status === 'pending' && d.expired && new Date(d.expired) < now
        );
        for (const d of expired) {
          try { await dbLib.updateDeposit(d.trxid, { status: 'expired' }); } catch (_) {}
        }
        if (expired.length) console.log(`[expiry] Marked ${expired.length} deposit(s) as expired`);
      } catch (_) {}

      // QRIS Orders
      try {
        const result = await dbLib.getQrisOrders();
        const orders = result.qrisOrders || result || [];
        const expired = orders.filter(o =>
          o.status === 'pending' && o.expired && new Date(o.expired) < now
        );
        for (const o of expired) {
          try { await dbLib.updateQrisOrder(o.id, { status: 'expired' }); } catch (_) {}
        }
        if (expired.length) console.log(`[expiry] Marked ${expired.length} QRIS order(s) as expired`);
      } catch (_) {}
    } catch (_) {}
  }

  // Jalankan sekali saat startup (delay 30 detik), lalu setiap 3 menit
  setTimeout(runExpiry, 30 * 1000);
  setInterval(runExpiry, 3 * 60 * 1000);
}

// ── Telegram Bot Manager ─────────────────────────────────
function startBotManager() {
  try {
    const botManager = require('./lib/bot-manager');
    // Delay startup 5 detik agar server fully ready
    setTimeout(() => {
      botManager.loadAllBots();
      // Cek expiry setiap jam
      setInterval(() => botManager.checkExpiry(), 60 * 60 * 1000);
    }, 5000);
  } catch (e) {
    console.error('[BotManager] Gagal start:', e.message);
  }
}

module.exports = app;
