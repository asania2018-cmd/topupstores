// ===== HAMBURGER NAV =====
function toggleNav() {
  const nav = document.getElementById('navLinks');
  const btn = document.getElementById('navHamburger');
  const open = nav.classList.toggle('open');
  btn.classList.toggle('active', open);
}

// Tutup nav saat klik link di dalam (mobile)
document.addEventListener('DOMContentLoaded', () => {
  const navLinks = document.getElementById('navLinks');
  if (navLinks) {
    navLinks.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        navLinks.classList.remove('open');
        const btn = document.getElementById('navHamburger');
        if (btn) btn.classList.remove('active');
      });
    });
  }

  // Tutup nav saat klik di luar
  document.addEventListener('click', e => {
    const nav = document.getElementById('navLinks');
    const btn = document.getElementById('navHamburger');
    if (nav && btn && !nav.contains(e.target) && !btn.contains(e.target)) {
      nav.classList.remove('open');
      btn.classList.remove('active');
    }
  });

  // Auto-dismiss alerts setelah 5 detik
  document.querySelectorAll('.alert').forEach(el => {
    if (!el.closest('.qris-result')) {
      setTimeout(() => {
        el.style.transition = 'opacity .5s';
        el.style.opacity = '0';
        setTimeout(() => el.remove(), 500);
      }, 5000);
    }
  });

  // Sidebar active link highlight
  const path = window.location.pathname;
  document.querySelectorAll('.sidebar-nav a').forEach(a => {
    if (a.getAttribute('href') === path) a.classList.add('active');
  });

  // Code tabs
  document.querySelectorAll('.code-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      tab.closest('.code-tabs').querySelectorAll('.code-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
    });
  });
});

// ===== TOAST =====
function showToast(msg, type = 'info') {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.className = 'show';
  setTimeout(() => toast.className = '', 3000);
}

// ===== COPY TO CLIPBOARD =====
function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => showToast('Disalin!'));
}

// ===== FORMAT RUPIAH =====
function formatRupiah(num) {
  return 'Rp' + parseInt(num).toLocaleString('id-ID');
}

// ===== SMOOTH SCROLL =====
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const id = a.getAttribute('href').slice(1);
    const el = document.getElementById(id);
    if (el) {
      e.preventDefault();
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});
