'use strict';
const express = require('express');
const router  = express.Router();
const { v4: uuidv4 } = require('uuid');
const db   = require('../lib/github-db');
const oke  = require('../lib/okeconnect');
const { apikeyMiddleware } = require('../lib/auth');
const { readProducts, findProduct, getAllCategories } = require('../lib/products');
const { calcPrice, getConfig } = require('../lib/pricing');
const { withLock, withProviderLimit } = require('../lib/mutex');

// ── Formatter helpers ─────────────────────────
function fmtRp(n) { return 'Rp' + parseInt(n || 0).toLocaleString('id-ID'); }

// Build a clean flat item object from the varians-based product format.
// prod    = { id, nama, icon_url, format_order, varians: [{id, nama, items:[]}] }
// varian  = { id, nama, icon_url, items: [{kode, nama, harga, ...}] }
// item    = { kode, nama, harga, icon, populer, promo, status }
function buildItem(prod, varian, item, cat, role) {
  return {
    kode:           item.kode,
    nama:           item.nama,
    produk:         prod.nama,
    produk_id:      prod.id,
    // icon_url: ikut di level varian/produk, digunakan bot sebagai thumbnail otomatis
    icon_url:       varian?.icon_url || prod.icon_url || prod.gambar || null,
    produk_gambar:  prod.icon_url || prod.gambar || null,
    kategori:       varian ? varian.nama : (item.kategori || null),
    kategori_id:    cat,
    format_order:   prod.format_order || 'normal',
    harga:          calcPrice(parseInt(item.harga || 0), cat, role),
    harga_format:   fmtRp(calcPrice(parseInt(item.harga || 0), cat, role)),
    populer:        item.populer || false,
    promo:          item.promo   || false,
    status:         item.status  || '1'
  };
}

// ── CALLBACK (no auth needed) ─────────────────
router.post('/callback', async (req, res) => {
  try {
    const data     = { ...req.body, ...req.query };
    const refID    = data.refID || data.ref_id || data.trxid || '';
    const rawSt    = (data.status || data.rc || '').toString().toUpperCase();
    const message  = data.message || data.keterangan || data.desc || '';
    const memberID = data.memberID || data.member_id || '';

    const expectedMember = process.env.OKE_MEMBER_ID || '';
    if (expectedMember && memberID && memberID !== expectedMember)
      return res.status(403).send('FORBIDDEN');
    if (!refID) return res.send('OK');

    let newStatus = 'pending';
    if (['SUKSES','SUCCESS','BERHASIL','00'].includes(rawSt))  newStatus = 'success';
    else if (['GAGAL','FAILED','ERROR'].includes(rawSt))       newStatus = 'failed';
    else {
      const u = message.toUpperCase();
      if (u.includes('SUKSES') || u.includes('BERHASIL') || u.includes('SUCCESS')) newStatus = 'success';
      else if (u.includes('GAGAL') || u.includes('FAILED'))                        newStatus = 'failed';
    }

    const { transactions, sha } = await db.getTransactions();
    const idx = transactions.findIndex(t => t.ref_id === refID || t.id === refID);
    if (idx !== -1) {
      const old = transactions[idx].status;
      // Idempotency: jangan overwrite status final (success/failed) dengan pending
      if (old !== newStatus && !(old === 'success' && newStatus === 'pending') && !(old === 'failed' && newStatus === 'pending')) {
        transactions[idx].status           = newStatus;
        transactions[idx].provider_message = message || transactions[idx].provider_message;
        transactions[idx].updated_at       = new Date().toISOString();
        await db.saveTransactions(transactions, sha);
      }
      if (newStatus === 'failed' && old !== 'failed') {
        try {
          const u = await db.findUser({ id: transactions[idx].user_id });
          if (u) await db.updateUser(u.id, { balance: u.balance + transactions[idx].amount });
        } catch (_) {}
      }
    }
    res.send('OK');
  } catch (e) { res.send('OK'); }
});

router.get('/callback', async (req, res) => {
  try {
    const data     = req.query;
    const refID    = data.refID || data.ref_id || data.trxid || '';
    const rawSt    = (data.status || data.rc || '').toString().toUpperCase();
    const message  = data.message || data.keterangan || data.desc || '';
    const memberID = data.memberID || data.member_id || '';

    const expected = process.env.OKE_MEMBER_ID || '';
    if (expected && memberID && memberID !== expected) return res.status(403).send('FORBIDDEN');
    if (!refID) return res.send('OK');

    let newStatus = 'pending';
    if (['SUKSES','SUCCESS','BERHASIL','00'].includes(rawSt))  newStatus = 'success';
    else if (['GAGAL','FAILED','ERROR'].includes(rawSt))       newStatus = 'failed';
    else {
      const u = message.toUpperCase();
      if (u.includes('SUKSES') || u.includes('BERHASIL')) newStatus = 'success';
      else if (u.includes('GAGAL') || u.includes('FAILED')) newStatus = 'failed';
    }

    const { transactions, sha } = await db.getTransactions();
    const idx = transactions.findIndex(t => t.ref_id === refID || t.id === refID);
    if (idx !== -1) {
      const old = transactions[idx].status;
      // Idempotency: jangan overwrite status final (success/failed) dengan pending
      if (old !== newStatus && !(old === 'success' && newStatus === 'pending') && !(old === 'failed' && newStatus === 'pending')) {
        transactions[idx].status           = newStatus;
        transactions[idx].provider_message = message || transactions[idx].provider_message;
        transactions[idx].updated_at       = new Date().toISOString();
        await db.saveTransactions(transactions, sha);
      }
      if (newStatus === 'failed' && old !== 'failed') {
        try {
          const u = await db.findUser({ id: transactions[idx].user_id });
          if (u) await db.updateUser(u.id, { balance: u.balance + transactions[idx].amount });
        } catch (_) {}
      }
    }
    res.send('OK');
  } catch (e) { res.send('OK'); }
});

// ── All requests below require API key ────────
router.use(apikeyMiddleware);

// ════════════════════════════════════════════
// GET /api/categories
// ════════════════════════════════════════════
// Daftar semua kategori tersedia dengan:
// - nama kategori, gambar (dari produk pertama), total_produk, total_group, total_item
// Items TIDAK termasuk. Gunakan /api/categories/:category untuk daftar produk,
// dan /api/game/:game_id untuk items.
router.get('/categories', (req, res) => {
  try {
    const role = req.apiUser.role;
    const data = [];

    for (const cat of getAllCategories()) {
      const products = readProducts(cat);
      let total_item  = 0;
      let total_group = 0;
      let gambar = null;

      for (const prod of products) {
        const varians = prod.varians || [];
        total_group += varians.length;
        for (const varian of varians) {
          const active = (varian.items || []).filter(i => i.status !== '0');
          total_item += active.length;
        }
        if (!gambar) gambar = prod.icon_url || prod.gambar || null;
      }

      data.push({
        kategori_id:  cat,
        nama:         cat.charAt(0).toUpperCase() + cat.slice(1),
        gambar,
        total_produk: products.length,
        total_group,
        total_item
      });
    }

    res.json({ status: true, creator: process.env.SITE_NAME, total: data.length, data });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ════════════════════════════════════════════
// GET /api/categories/:category
// ════════════════════════════════════════════
// Daftar produk/game dalam satu kategori.
// Setiap entri berisi: id, nama, gambar, format_order, total_group, total_item, harga_mulai.
// Items TIDAK disertakan. Gunakan GET /api/game/:game_id untuk itemnya.
router.get('/categories/:category', (req, res) => {
  try {
    const { category } = req.params;
    const role = req.apiUser.role;
    const valid = getAllCategories();
    if (!valid.includes(category))
      return res.json({ status: false, message: `Kategori tidak valid. Pilihan: ${valid.join(', ')}` });

    const products = readProducts(category);
    const data = [];

    for (const prod of products) {
      const varians = prod.varians || [];
      let total_item  = 0;
      const total_group = varians.length;
      const allPrices = [];

      for (const varian of varians) {
        const active = (varian.items || []).filter(i => i.status !== '0');
        total_item += active.length;
        for (const item of active) {
          const p = calcPrice(parseInt(item.harga || 0), category, role);
          if (p > 0) allPrices.push(p);
        }
      }

      if (total_item === 0) continue;

      const harga_mulai = allPrices.length ? Math.min(...allPrices) : 0;

      data.push({
        id:           prod.id,
        nama:         prod.nama,
        gambar:       prod.icon_url || prod.gambar || null,
        format_order: prod.format_order || 'normal',
        populer:      prod.populer || false,
        total_group,
        total_item,
        harga_mulai,
        harga_mulai_format: harga_mulai ? fmtRp(harga_mulai) : null
      });
    }

    res.json({
      status: true, creator: process.env.SITE_NAME,
      kategori: category,
      total: data.length,
      data
    });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ════════════════════════════════════════════
// GET /api/game/:game_id
// ════════════════════════════════════════════
// Detail produk/game berikut seluruh items-nya (dipisah dari kategori).
// game_id dapat berupa prod.id atau prod.nama (URL-encoded).
// Respons: { id, nama, gambar, format_order, total_group, total_item, groups:[...] }
// groups[].items[] berisi: { kode, nama, harga, harga_format, populer, promo }
// Gambar hanya ada di level produk/group, TIDAK di item.
router.get('/game/:game_id', (req, res) => {
  try {
    const { game_id } = req.params;
    const role = req.apiUser.role;
    const query = decodeURIComponent(game_id).toLowerCase();

    for (const cat of getAllCategories()) {
      const products = readProducts(cat);
      const prod = products.find(p =>
        p.id === game_id ||
        p.nama.toLowerCase() === query
      );
      if (!prod) continue;

      const groups   = [];
      let total_item = 0;

      for (const varian of (prod.varians || [])) {
        const activeItems = (varian.items || [])
          .filter(i => i.status !== '0')
          .map(i => ({
            kode:           i.kode,
            nama:           i.nama,
            harga:          calcPrice(parseInt(i.harga || 0), cat, role),
            harga_format:   fmtRp(calcPrice(parseInt(i.harga || 0), cat, role)),
            populer:        i.populer || false,
            promo:          i.promo   || false
          }))
          .sort((a, b) => a.harga - b.harga);

        if (!activeItems.length) continue;
        total_item += activeItems.length;

        groups.push({
          group_id:   varian.id,
          group_nama: varian.nama,
          icon_url:   varian.icon_url || null,
          total:      activeItems.length,
          items:      activeItems
        });
      }

      return res.json({
        status:       true,
        creator:      process.env.SITE_NAME,
        id:           prod.id,
        nama:         prod.nama,
        gambar:       prod.icon_url || prod.gambar || null,
        format_order: prod.format_order || 'normal',
        populer:      prod.populer || false,
        kategori_id:  cat,
        total_group:  groups.length,
        total_item,
        groups
      });
    }

    res.json({ status: false, message: `Game "${game_id}" tidak ditemukan` });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ════════════════════════════════════════════
// GET /api/products  (fixed: uses varians format)
// ════════════════════════════════════════════
// Query params: category, search
router.get('/products', (req, res) => {
  try {
    const { category, search } = req.query;
    const role       = req.apiUser.role;
    const categories = category ? [category] : getAllCategories();
    const result     = {};

    for (const cat of categories) {
      const products = readProducts(cat);
      const items    = [];

      for (const prod of products) {
        for (const varian of (prod.varians || [])) {
          for (const item of (varian.items || [])) {
            if (item.status === '0') continue;
            if (search) {
              const q = search.toLowerCase();
              if (!(item.kode.toLowerCase().includes(q) ||
                    item.nama.toLowerCase().includes(q) ||
                    prod.nama.toLowerCase().includes(q))) continue;
            }
            items.push(buildItem(prod, varian, item, cat, role));
          }
        }
      }
      result[cat] = items;
    }

    if (category) {
      const arr = result[category] || [];
      return res.json({ status: true, creator: process.env.SITE_NAME, total: arr.length, data: arr });
    }
    const total = Object.values(result).reduce((s, a) => s + a.length, 0);
    res.json({ status: true, creator: process.env.SITE_NAME, total, data: result });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ── GET /api/products/category/:category ──────
router.get('/products/category/:category', (req, res) => {
  try {
    const { category } = req.params;
    const { search }   = req.query;
    const role         = req.apiUser.role;
    const valid        = getAllCategories();
    if (!valid.includes(category))
      return res.json({ status: false, message: `Kategori tidak valid. Pilihan: ${valid.join(', ')}` });

    const products = readProducts(category);
    const items    = [];

    for (const prod of products) {
      for (const varian of (prod.varians || [])) {
        for (const item of (varian.items || [])) {
          if (item.status === '0') continue;
          if (search) {
            const q = search.toLowerCase();
            if (!(item.kode.toLowerCase().includes(q) ||
                  item.nama.toLowerCase().includes(q) ||
                  prod.nama.toLowerCase().includes(q))) continue;
          }
          items.push(buildItem(prod, varian, item, category, role));
        }
      }
    }

    res.json({ status: true, creator: process.env.SITE_NAME, kategori: category, total: items.length, data: items });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ── GET /api/product/:kode ────────────────────
router.get('/product/:kode', (req, res) => {
  try {
    const role    = req.apiUser.role;
    const product = findProduct(req.params.kode);
    if (!product)
      return res.json({ status: false, message: `Produk "${req.params.kode}" tidak ditemukan` });

    const cat       = product.category;
    const basePrice = parseInt(product.harga || 0);
    const sellPrice = calcPrice(basePrice, cat, role);

    res.json({
      status: true, creator: process.env.SITE_NAME,
      data: {
        kode:           product.kode,
        nama:           product.keterangan || product.nama,
        produk:         product.produk,
        produk_id:      product.produk_id || null,
        gambar:         product.gambar || null,
        kategori:       product.subkategori || null,
        kategori_id:    cat,
        format_order:   product.format_order || 'normal',
        harga:          sellPrice,
        harga_format:   fmtRp(sellPrice),
        status:         product.status || '1'
      }
    });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ── GET /api/variants/:category ───────────────
// Produk dikelompokkan per brand, setiap brand memiliki gambar + items[]
router.get('/variants/:category', (req, res) => {
  try {
    const { category } = req.params;
    const { produk: filterProduk } = req.query;
    const role  = req.apiUser.role;
    const valid = getAllCategories();
    if (!valid.includes(category))
      return res.json({ status: false, message: `Kategori tidak valid. Pilihan: ${valid.join(', ')}` });

    const products = readProducts(category);
    const grouped  = {};

    for (const prod of products) {
      if (filterProduk && !prod.nama.toLowerCase().includes(filterProduk.toLowerCase())) continue;

      const allItems = [];
      for (const varian of (prod.varians || [])) {
        for (const item of (varian.items || [])) {
          if (item.status === '0') continue;
          allItems.push(buildItem(prod, varian, item, category, role));
        }
      }
      if (!allItems.length) continue;
      allItems.sort((a, b) => a.harga - b.harga);

      grouped[prod.nama] = {
        id:           prod.id,
        produk:       prod.nama,
        gambar:       prod.icon_url || prod.gambar || null,
        format_order: prod.format_order || 'normal',
        populer:      prod.populer || false,
        total:        allItems.length,
        items:        allItems
      };
    }

    res.json({
      status: true, creator: process.env.SITE_NAME,
      kategori:     category,
      total_produk: Object.keys(grouped).length,
      data:         grouped
    });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ── GET /api/variants/:category/:produk ───────
router.get('/variants/:category/:produk', (req, res) => {
  try {
    const { category, produk } = req.params;
    const role  = req.apiUser.role;
    const valid = getAllCategories();
    if (!valid.includes(category))
      return res.json({ status: false, message: `Kategori tidak valid. Pilihan: ${valid.join(', ')}` });

    const products = readProducts(category);
    const q        = decodeURIComponent(produk).toLowerCase();
    const matched  = products.find(p =>
      p.nama.toLowerCase().includes(q) || p.id === produk
    );

    if (!matched)
      return res.json({ status: false, message: `Produk "${produk}" tidak ditemukan di kategori ${category}` });

    const items = [];
    for (const varian of (matched.varians || [])) {
      for (const item of (varian.items || [])) {
        if (item.status === '0') continue;
        items.push(buildItem(matched, varian, item, category, role));
      }
    }
    items.sort((a, b) => a.harga - b.harga);

    res.json({
      status: true, creator: process.env.SITE_NAME,
      produk:       matched.nama,
      produk_id:    matched.id,
      gambar:       matched.icon_url || matched.gambar || null,
      format_order: matched.format_order || 'normal',
      kategori:     category,
      total:        items.length,
      data:         items
    });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ── POST /api/order ───────────────────────────
router.post('/order', async (req, res) => {
  const { product_code, target, zone_id, ref_id } = req.body;
  if (!product_code || !target)
    return res.json({ status: false, message: 'product_code dan target wajib diisi' });

  try {
    const user = await db.findUser({ id: req.apiUser.id });
    if (!user) return res.json({ status: false, message: 'User tidak ditemukan' });

    const product = findProduct(product_code);
    if (!product)
      return res.json({ status: false, message: 'Produk tidak ditemukan: ' + product_code });

    // Validasi zone_id untuk produk yang membutuhkannya
    if (product.format_order === 'zone' && !zone_id)
      return res.json({ status: false, message: 'Produk ini membutuhkan zone_id (contoh: Mobile Legends membutuhkan zone ID)' });

    const cat       = product.category;
    const basePrice = parseInt(product.harga || 0);
    const sellPrice = calcPrice(basePrice, cat, user.role);

    // Cek saldo sebelum proses — pesan yang jelas
    if (user.balance < sellPrice)
      return res.json({
        status: false,
        message: `Saldo tidak cukup`,
        data: {
          saldo_anda:    user.balance,
          saldo_format:  fmtRp(user.balance),
          harga:         sellPrice,
          harga_format:  fmtRp(sellPrice),
          kekurangan:    sellPrice - user.balance,
          kekurangan_format: fmtRp(sellPrice - user.balance)
        }
      });

    let dest = target;
    if (product.format_order === 'zone' && zone_id) {
      dest = `${target}(${zone_id})`;
    } else if (['pulsa','data','ewallet'].includes(cat)) {
      dest = target.replace(/[^0-9]/g, '');
      if (dest.startsWith('62') && dest.length >= 10) dest = '0' + dest.substring(2);
    }

    const refID = ref_id || ('TRX' + Date.now().toString().slice(-8));
    const trxId = 'H2H-' + uuidv4().split('-')[0].toUpperCase();

    // ── ATOMIC balance deduct: lock per user — cegah double-deduct concurrent ──
    // withLock memastikan hanya 1 request yang bisa read-check-deduct saldo user ini
    let origBal, freshUser;
    try {
      const deductResult = await withLock('balance:' + user.id, async () => {
        const fu = await db.findUser({ id: user.id });
        if (!fu) throw new Error('User tidak ditemukan');
        if (fu.balance < sellPrice) return { ok: false, user: fu };
        await db.updateUser(fu.id, { balance: fu.balance - sellPrice });
        return { ok: true, origBal: fu.balance, user: fu };
      });
      if (!deductResult.ok) {
        return res.json({
          status: false,
          message: 'Saldo tidak cukup',
          data: {
            saldo_anda:        deductResult.user.balance,
            saldo_format:      fmtRp(deductResult.user.balance),
            harga:             sellPrice,
            harga_format:      fmtRp(sellPrice),
            kekurangan:        sellPrice - deductResult.user.balance,
            kekurangan_format: fmtRp(sellPrice - deductResult.user.balance)
          }
        });
      }
      origBal  = deductResult.origBal;
      freshUser = deductResult.user;
    } catch (lockErr) {
      return res.json({ status: false, message: lockErr.message });
    }

    let okeResp;
    try {
      okeResp = await withProviderLimit(() => oke.order(product_code, dest, refID));
    } catch (provErr) {
      await db.updateUser(freshUser.id, { balance: origBal });
      await db.addTransaction({
        id: trxId, user_id: user.id, username: user.username, apikey: user.apikey,
        product_code, product_name: product.keterangan || product_code,
        category: cat, target, zone_id: zone_id || null, dest, ref_id: refID,
        amount: sellPrice, provider_price: basePrice, status: 'failed',
        provider_message: 'Provider error: ' + provErr.message,
        created_at: new Date().toISOString()
      });
      return res.json({ status: false, message: 'Gagal menghubungi provider: ' + provErr.message });
    }

    const status = okeResp.status;
    if (status === 'failed') await db.updateUser(freshUser.id, { balance: origBal });

    const trx = {
      id: trxId, user_id: freshUser.id, username: freshUser.username, apikey: freshUser.apikey,
      product_code, product_name: product.keterangan || product_code,
      category: cat, target, zone_id: zone_id || null, dest, ref_id: refID,
      amount: sellPrice, provider_price: basePrice, status,
      provider_message: okeResp.message,
      created_at: new Date().toISOString()
    };
    await db.addTransaction(trx);

    res.json({
      status: true, creator: process.env.SITE_NAME,
      data: {
        trx_id:           trxId,
        ref_id:           refID,
        product_code,
        product_name:     trx.product_name,
        kategori:         cat,
        target,
        zone_id:          zone_id || null,
        amount:           sellPrice,
        amount_format:    fmtRp(sellPrice),
        status,
        message:          okeResp.message,
        created_at:       trx.created_at,
        note: status === 'pending'
          ? 'Order sedang diproses. Gunakan GET /api/status/' + trxId + ' untuk cek status terbaru.'
          : null
      }
    });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ── GET /api/status/:trx_id ───────────────────
router.get('/status/:trx_id', async (req, res) => {
  try {
    const { transactions } = await db.getTransactions();
    const trx = transactions.find(t => t.id === req.params.trx_id || t.ref_id === req.params.trx_id);
    if (!trx) return res.json({ status: false, message: 'Transaksi tidak ditemukan' });
    if (trx.user_id !== req.apiUser.id && req.apiUser.role !== 'admin')
      return res.json({ status: false, message: 'Akses ditolak' });

    if (trx.status === 'pending') {
      try {
        // FIX: gunakan ref_id || id — beberapa transaksi menyimpan refID di field 'id', bukan 'ref_id'
        const refIdForCheck = trx.ref_id || trx.id;
        const check = await oke.checkStatus(trx.product_code, trx.dest, refIdForCheck);

        if (check.status === 'success' || check.status === 'failed') {
          const { transactions: allTrx, sha } = await db.getTransactions();
          const idx = allTrx.findIndex(t => t.id === trx.id);
          if (idx !== -1) {
            const prevStatus = allTrx[idx].status;
            allTrx[idx].status           = check.status;
            allTrx[idx].provider_message = check.message;
            allTrx[idx].updated_at       = new Date().toISOString();
            await db.saveTransactions(allTrx, sha);
            trx.status           = check.status;
            trx.provider_message = check.message;

            // FIX: Kembalikan saldo jika order gagal
            if (check.status === 'failed' && prevStatus !== 'failed') {
              try {
                const u = await db.findUser({ id: trx.user_id });
                if (u) await db.updateUser(u.id, { balance: (u.balance || 0) + (trx.amount || 0) });
              } catch (_) {}
            }
          }
        }
      } catch (_) {
        // Jika OkeConnect error, biarkan status tetap pending — jangan crash
      }
    }

    res.json({
      status: true, creator: process.env.SITE_NAME,
      data: {
        trx_id:        trx.id,
        ref_id:        trx.ref_id || trx.id,
        product_code:  trx.product_code,
        product_name:  trx.product_name,
        kategori:      trx.category,
        target:        trx.target,
        zone_id:       trx.zone_id || null,
        amount:        trx.amount,
        amount_format: fmtRp(trx.amount),
        status:        trx.status,
        message:       trx.provider_message,
        created_at:    trx.created_at,
        updated_at:    trx.updated_at || null
      }
    });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ── GET /api/balance ──────────────────────────
// FIX: Menampilkan role user (reseller / regular) agar developer bisa verifikasi deteksi role
router.get('/balance', async (req, res) => {
  try {
    const user = await db.findUser({ id: req.apiUser.id });
    res.json({
      status: true, creator: process.env.SITE_NAME,
      data: {
        username:       user.username,
        role:           user.role,
        is_reseller:    user.role === 'reseller',
        balance:        user.balance,
        balance_format: fmtRp(user.balance),
        note:           user.role === 'reseller'
          ? 'Harga menggunakan tarif reseller (lebih murah)'
          : 'Harga menggunakan tarif regular'
      }
    });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ── GET /api/history ──────────────────────────
router.get('/history', async (req, res) => {
  try {
    const { transactions } = await db.getTransactions();
    const limit    = Math.min(parseInt(req.query.limit) || 20, 100);
    const { category, status } = req.query;

    let list = transactions.filter(t => t.user_id === req.apiUser.id);
    if (category) list = list.filter(t => t.category === category);
    if (status)   list = list.filter(t => t.status   === status);
    list = list.slice(0, limit);

    res.json({
      status: true, creator: process.env.SITE_NAME,
      total: list.length,
      data: list.map(t => ({
        trx_id:           t.id,
        ref_id:           t.ref_id || t.id,
        product_code:     t.product_code,
        product_name:     t.product_name,
        kategori:         t.category,
        target:           t.target,
        zone_id:          t.zone_id || null,
        amount:           t.amount,
        amount_format:    fmtRp(t.amount),
        status:           t.status,
        message:          t.provider_message,
        created_at:       t.created_at,
        updated_at:       t.updated_at || null
      }))
    });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

module.exports = router;
