'use strict';
const express = require('express');
const router  = express.Router();
const { withLock, withProviderLimit } = require('../lib/mutex');
const path    = require('path');
const fs      = require('fs');
const { v4: uuidv4 } = require('uuid');
const moment  = require('moment');
const db   = require('../lib/github-db');
const oke  = require('../lib/okeconnect');
const { authMiddleware, generateApiKey } = require('../lib/auth');
const {
  readProducts, readProductsFlat,
  getAllCategories, findProduct
} = require('../lib/products');
const { calcPrice, getConfig } = require('../lib/pricing');
const { getBrandLogo } = require('../lib/brand-logos');
const { getActive: getActiveAnnouncements } = require('../lib/announcements');
const { createQris, checkQrisStatus, cancelQris } = require('../lib/payqris');
const { sendOrderReceiptEmail } = require('../lib/email');
const botManager = require('../lib/bot-manager');
// ── helpers ──────────────────────────────────
function readJson(p, d) {
  try { if (!fs.existsSync(p)) return d; return JSON.parse(fs.readFileSync(p, 'utf-8')); }
  catch { return d; }
}

function incrementFlashSaleSold(productCode) {
  if (!productCode) return;
  try {
    const fp = path.join(__dirname, '../data/flashsale.json');
    const list = readJson(fp, []);
    const idx = list.findIndex(function(f){ return f.kode === productCode && f.active !== false; });
    if (idx !== -1) {
      list[idx].total_dibeli = (list[idx].total_dibeli || 0) + 1;
      fs.writeFileSync(fp, JSON.stringify(list, null, 2));
    }
  } catch(e) {}
}
function getPromoPath() { return path.join(__dirname, '../data/promo.json'); }
function formatRp(n) { return 'Rp' + parseInt(n || 0).toLocaleString('id-ID'); }

// ── promo helpers ────────────────────────────
function validatePromo(code, amount, category) {
  if (!code) return null;
  const promos = readJson(getPromoPath(), []);
  const promo  = promos.find(p => p.code.toUpperCase() === code.toUpperCase().trim() && p.active);
  if (!promo) return { error: 'Kode promo tidak valid atau tidak aktif' };
  if (promo.expires_at && new Date(promo.expires_at) < new Date()) return { error: 'Kode promo sudah kadaluarsa' };
  if (promo.max_uses > 0 && promo.used_count >= promo.max_uses) return { error: 'Kode promo sudah habis digunakan' };
  if (promo.min_order > 0 && amount < promo.min_order)
    return { error: `Minimum order ${formatRp(promo.min_order)} untuk promo ini` };
  if (promo.applies_to && promo.applies_to !== 'all' && promo.applies_to !== category)
    return { error: `Promo hanya berlaku untuk kategori ${promo.applies_to}` };
  let discount = promo.type === 'percent'
    ? Math.round(amount * promo.value / 100)
    : promo.value;
  discount = Math.min(discount, amount);
  return { promo, discount };
}
function applyPromoUsage(code) {
  try {
    const f = getPromoPath();
    const promos = readJson(f, []);
    const idx = promos.findIndex(p => p.code.toUpperCase() === code.toUpperCase().trim());
    if (idx !== -1) { promos[idx].used_count = (promos[idx].used_count || 0) + 1; fs.writeFileSync(f, JSON.stringify(promos, null, 2)); }
  } catch {}
}

// ── game display helpers ─────────────────────
function getGameGradient(nama) {
  if (!nama) return 'linear-gradient(135deg,#0d2b6b,#1d4ed8)';
  const n = nama.toLowerCase();
  if (n.includes('mobile legend')) return 'linear-gradient(135deg,#1a237e,#6a1b9a)';
  if (n.includes('free fire'))     return 'linear-gradient(135deg,#b71c1c,#e64a19)';
  if (n.includes('genshin'))       return 'linear-gradient(135deg,#6a1b9a,#0d47a1)';
  if (n.includes('honkai'))        return 'linear-gradient(135deg,#880e4f,#311b92)';
  if (n.includes('google'))        return 'linear-gradient(135deg,#1b5e20,#004d40)';
  if (n.includes('pubg'))          return 'linear-gradient(135deg,#e65100,#bf360c)';
  if (n.includes('roblox'))        return 'linear-gradient(135deg,#1c1c1c,#3c3c3c)';
  return 'linear-gradient(135deg,#0d2b6b,#1565c0)';
}
function getGameAbbr(nama) {
  if (!nama) return 'G';
  const n = nama.toLowerCase();
  if (n.includes('mobile legend')) return 'ML';
  if (n.includes('free fire'))     return 'FF';
  if (n.includes('genshin'))       return 'GI';
  if (n.includes('honkai'))        return 'HSR';
  if (n.includes('google'))        return 'GP';
  if (n.includes('pubg'))          return 'PUBG';
  return nama.substring(0, 2).toUpperCase();
}
function getCleanName(nama) {
  return (nama || 'Game')
    .replace(/^TPG\s+/i, '').replace(/^Top\s+Up\s+/i, '')
    .replace(/^Voucher\s+/i, '').trim();
}
const providerColors = {
  Telkomsel: 'linear-gradient(135deg,#c62828,#6a1b9a)',
  Indosat:   'linear-gradient(135deg,#f57f17,#e65100)',
  Axis:      'linear-gradient(135deg,#4527a0,#6a1b9a)',
  XL:        'linear-gradient(135deg,#0d47a1,#1565c0)',
  Smartfren: 'linear-gradient(135deg,#880e4f,#ad1457)',
  Tri:       'linear-gradient(135deg,#1b5e20,#2e7d32)',
  DANA:      'linear-gradient(135deg,#1565c0,#0288d1)',
  GoPay:     'linear-gradient(135deg,#00695c,#0097a7)',
  ShopeePay: 'linear-gradient(135deg,#e64a19,#bf360c)',
  LinkAja:   'linear-gradient(135deg,#c62828,#b71c1c)',
  OVO:       'linear-gradient(135deg,#6a1b9a,#4a148c)',
  Alfamart:  'linear-gradient(135deg,#c62828,#e64a19)',
};
function getProviderColor(nama) { return providerColors[nama] || 'linear-gradient(135deg,#0d2b6b,#1565c0)'; }

// ── build group data ─────────────────────────
function buildGameGroups(rawProducts, role) {
  return rawProducts.map(prod => {
    let items = [];
    let totalCount = 0;
    if (prod.varians && prod.varians.length > 0) {
      for (const varian of prod.varians) {
        for (const item of (varian.items || [])) {
          totalCount++;
          const disabled = item.status === '0';
          items.push({
            kode: item.kode, nama: item.nama,
            harga: calcPrice(parseInt(item.harga || 0), 'game', role),
            icon: item.icon || varian.icon_url || null,
            kategori: varian.nama, populer: item.populer || false, promo: item.promo || false,
            disabled
          });
        }
      }
    } else {
      const all = prod.items || [];
      totalCount = all.length;
      items = all.map(i => ({
        kode: i.kode, nama: i.nama,
        harga: calcPrice(parseInt(i.harga || 0), 'game', role),
        icon: i.icon || null, kategori: i.kategori || null, populer: i.populer || false, promo: i.promo || false,
        disabled: i.status === '0'
      }));
    }
    items.sort((a, b) => a.harga - b.harga);
    const activeItems = items.filter(i => !i.disabled);
    const prices = activeItems.map(i => i.harga).filter(h => h > 0);
    const gangguan = totalCount > 0 && activeItems.length === 0;
    return {
      id: prod.id, produk: prod.nama, cleanedName: getCleanName(prod.nama),
      abbr: getGameAbbr(prod.nama), gradient: getGameGradient(prod.nama),
      logo: prod.icon_url || prod.gambar || getBrandLogo(prod.nama) || null,
      banner_url: prod.banner_url || null, format_order: prod.format_order || 'normal',
      populer: prod.populer || false, minPrice: prices.length ? Math.min(...prices) : 0, items,
      checknicname_api: prod.checknicname_api || null,
      checknicname_path: prod.checknicname_path || null,
      deskripsi: prod.deskripsi || null,
      gangguan
    };
  }).filter(g => g.items.length > 0 || g.gangguan);
}
function buildProviderGroups(rawProducts, cat, role) {
  return rawProducts.map(prod => {
    let items = [];
    let totalCount = 0;
    if (prod.varians && prod.varians.length > 0) {
      for (const varian of prod.varians) {
        for (const item of (varian.items || [])) {
          totalCount++;
          const disabled = item.status === '0';
          items.push({
            kode: item.kode, nama: item.nama,
            harga: calcPrice(parseInt(item.harga || 0), cat, role),
            icon: item.icon || varian.icon_url || null,
            kategori: varian.nama,
            populer: item.populer || false, promo: item.promo || false,
            disabled
          });
        }
      }
    } else {
      const all = prod.items || [];
      totalCount = all.length;
      items = all.map(i => ({
        kode: i.kode, nama: i.nama,
        harga: calcPrice(parseInt(i.harga || 0), cat, role),
        icon: i.icon || null, kategori: i.kategori || null,
        populer: i.populer || false, promo: i.promo || false,
        disabled: i.status === '0'
      }));
    }
    items.sort((a, b) => a.harga - b.harga);
    const activeItems = items.filter(i => !i.disabled);
    const prices = activeItems.map(i => i.harga).filter(h => h > 0);
    const gangguan = totalCount > 0 && activeItems.length === 0;
    return {
      id: prod.id, produk: prod.nama,
      logo: prod.icon_url || prod.gambar || getBrandLogo(prod.nama) || null,
      populer: prod.populer || false, minPrice: prices.length ? Math.min(...prices) : 0, items,
      format_order: prod.format_order || 'normal',
      checknicname_api: prod.checknicname_api || null,
      checknicname_path: prod.checknicname_path || null,
      deskripsi: prod.deskripsi || null,
      gangguan
    };
  }).filter(g => g.items.length > 0 || g.gangguan);
}
function buildTagihanFlat(rawProducts, role) {
  const flat = [];
  for (const prod of rawProducts) {
    if (prod.varians) {
      for (const varian of prod.varians) {
        for (const i of (varian.items || [])) {
          if (i.status === '0') continue;
          flat.push({ kode: i.kode, nama: i.nama, harga: calcPrice(parseInt(i.harga || 0), 'tagihan', role), produk: prod.nama });
        }
      }
    } else {
      for (const i of (prod.items || [])) {
        if (i.status === '0') continue;
        flat.push({ kode: i.kode, nama: i.nama, harga: calcPrice(parseInt(i.harga || 0), 'tagihan', role), produk: prod.nama });
      }
    }
  }
  return flat.sort((a, b) => a.harga - b.harga);
}

// ── optional auth middleware ──────────────────
function optionalAuth(req, res, next) { next(); }

// ── API: validate promo (no auth required) ───
router.post('/api/promo/validate', express.json(), (req, res) => {
  const { code, amount, category } = req.body;
  const result = validatePromo(code, parseInt(amount) || 0, category);
  if (!result) return res.json({ status: false, message: 'Kode promo diperlukan' });
  if (result.error) return res.json({ status: false, message: result.error });
  res.json({
    status: true, discount: result.discount,
    final: Math.max(0, (parseInt(amount) || 0) - result.discount),
    message: `Diskon ${result.promo.type === 'percent' ? result.promo.value + '%' : formatRp(result.promo.value)} diterapkan!`
  });
});

// ── Pages ────────────────────────────────────
router.get('/', (req, res) => { res.redirect('/dashboard'); });

function getUnreadCount(user, announcements) {
  if (!user) return 0;
  const read = Array.isArray(user.read_announcements) ? user.read_announcements : [];
  return announcements.filter(a => !read.includes(a.id)).length;
}

router.get('/dashboard', optionalAuth, async (req, res) => {
  try {
    const sessionUser = req.session && req.session.user;
    let safeUser = null, myTrx = [], myDeposits = [], role = 'regular';

    if (sessionUser) {
      try {
        const user = await db.findUser({ id: sessionUser.id });
        if (user) {
          const { password: _, ...u } = user;
          safeUser = u;
          role = user.role;
          const { transactions } = await db.getTransactions();
          myTrx = transactions.filter(t => t.user_id === user.id).slice(0, 30);
          const { deposits: allDeposits } = await db.getDeposits();
          myDeposits = allDeposits.filter(d => d.user_id === user.id).slice(0, 20);
        }
      } catch {}
    }

    const gameGroups    = buildGameGroups(readProducts('game'), role);
    const ewalletGroups = buildProviderGroups(readProducts('ewallet'), 'ewallet', role);
    const pulsaGroups   = buildProviderGroups(readProducts('pulsa'), 'pulsa', role);
    const dataGroups    = buildProviderGroups(readProducts('data'), 'data', role);
    const tagihanItems  = buildTagihanFlat(readProducts('tagihan'), role);
    const streamingGroups = buildProviderGroups(readProducts('streaming'), 'streaming', role);
    const banners = readJson(path.join(__dirname, '../data/banners.json'), []).filter(b => b.active);
    const flashsale = (() => {
      try {
        const list = readJson(path.join(__dirname, '../data/flashsale.json'), []);
        const now = Date.now();
        return list.filter(f => f.active && (!f.ends_at || new Date(f.ends_at).getTime() > now));
      } catch { return []; }
    })();
    const announcements = getActiveAnnouncements();
    const unreadCount   = getUnreadCount(safeUser, announcements);

    res.render('dashboard', {
      user: safeUser, transactions: myTrx, deposits: myDeposits,
      gameGroups, ewalletGroups, pulsaGroups, dataGroups, tagihanItems, streamingGroups,
      banners, flashsale, announcements, unreadCount,
      getProviderColor, config: getConfig(),
      receipt: req.query.receipt || null,
      error: req.query.error || null, success: req.query.success || null
    });
  } catch (e) {
    res.render('dashboard', {
      user: null, transactions: [], deposits: [],
      gameGroups: [], ewalletGroups: [], pulsaGroups: [], dataGroups: [], tagihanItems: [], streamingGroups: [],
      banners: [], flashsale: [], announcements: [], unreadCount: 0,
      getProviderColor, config: {},
      receipt: null, error: e.message, success: null
    });
  }
});

router.post('/dashboard/reset-apikey', authMiddleware, async (req, res) => {
  try {
    await db.updateUser(req.session.user.id, { apikey: generateApiKey() });
    const user = await db.findUser({ id: req.session.user.id });
    const { password: _, ...safeUser } = user;
    req.session.user = safeUser;
    res.redirect('/dashboard?success=API+Key+berhasil+direset');
  } catch (e) { res.redirect('/dashboard?error=' + encodeURIComponent(e.message)); }
});

// ── CHECKNICNAME PROXY ──────────────────────────
router.get('/api/checknicname', async (req, res) => {
  const { api, uid, zone, path: jsonPath } = req.query;
  if (!api || !uid) return res.json({ status: false, message: 'api and uid required' });
  try {
    let url;
    if (api.includes('{uid}') || api.includes('{zoneid}')) {
      // Placeholder format: replace {uid} and {zoneid} in URL template
      url = api
        .replace(/\{uid\}/g, encodeURIComponent(uid))
        .replace(/\{zoneid\}/g, encodeURIComponent(zone || ''));
    } else {
      // Legacy format: append uid/zone as query params
      url = api + (api.includes('?') ? '&' : '?') + 'uid=' + encodeURIComponent(uid);
      if (zone) url += '&zone=' + encodeURIComponent(zone);
    }
    const r = await fetch(url, { signal: AbortSignal.timeout ? AbortSignal.timeout(5000) : undefined });
    const data = await r.json();
    if (jsonPath) {
      const parts = jsonPath.split('.');
      let val = data;
      for (const p of parts) { if (val == null) break; val = val[p]; }
      if (val) return res.json({ status: true, nickname: String(val) });
    }
    const nick = data.nickname || data.username || data.name || (data.data && (data.data.username || data.data.nickname || data.data.name)) || (data.result && (data.result.username || data.result.nickname || data.result.name));
    if (nick) return res.json({ status: true, nickname: String(nick) });
    return res.json({ status: false, message: 'Nickname tidak ditemukan' });
  } catch (e) { res.json({ status: false, message: e.message }); }
});

router.get('/topup', optionalAuth, (req, res) => {
  const role = req.session && req.session.user && req.session.user.role;
  const gameGroups       = buildGameGroups(readProducts('game'), role);
  const ewalletGroups    = buildProviderGroups(readProducts('ewallet'), 'ewallet', role);
  const pulsaGroups      = buildProviderGroups(readProducts('pulsa'), 'pulsa', role);
  const dataGroups       = buildProviderGroups(readProducts('data'), 'data', role);
  const tagihanItems     = buildTagihanFlat(readProducts('tagihan'), role);
  const streamingGroups  = buildProviderGroups(readProducts('streaming'), 'streaming', role);
  const flashsale = (() => {
    try {
      const list = readJson(path.join(__dirname, '../data/flashsale.json'), []);
      const now = Date.now();
      return list.filter(f => f.active && (!f.ends_at || new Date(f.ends_at).getTime() > now));
    } catch { return []; }
  })();
  const cfg = getConfig();
  const paymentMethods = (cfg.payment_methods || []).filter(m => m.enabled !== false);
  res.render('topup', {
    user: (req.session && req.session.user) || null,
    getProviderColor, config: cfg,
    gameGroups, ewalletGroups, pulsaGroups, dataGroups, tagihanItems,
    streamingGroups, flashsale, paymentMethods,
    selectedGame:     req.query.game     || null,
    selectedCat:      req.query.cat      || 'game',
    selectedProvider: req.query.provider || null,
    selectedKode:     req.query.kode     || null,
    error: req.query.error || null, success: req.query.success || null
  });
});

// ── ORDER via Saldo (logged-in) ───────────────
router.post('/topup/order', authMiddleware, async (req, res) => {
  const { product_code, target, zone_id, promo_code } = req.body;
  if (!product_code || !target)
    return res.redirect('/topup?error=' + encodeURIComponent('product_code dan target wajib diisi'));
  try {
    const userInit = await db.findUser({ id: req.session.user.id });
    if (!userInit) return res.redirect('/topup?error=' + encodeURIComponent('User tidak ditemukan'));
    const product = findProduct(product_code);
    if (!product) return res.redirect('/topup?error=' + encodeURIComponent('Produk tidak ditemukan: ' + product_code));
    const cat        = product.category;
    const sellPrice0 = calcPrice(parseInt(product.harga || 0), cat, userInit.role);
    let sellPrice = sellPrice0, promoDiscount = 0, appliedPromoCode = null;
    if (promo_code && promo_code.trim()) {
      const pr = validatePromo(promo_code.trim(), sellPrice, cat);
      if (pr && !pr.error) { promoDiscount = pr.discount; appliedPromoCode = promo_code.trim().toUpperCase(); sellPrice = Math.max(0, sellPrice - promoDiscount); }
    }
    // Early check (sebelum lock)
    if (userInit.balance < sellPrice)
      return res.redirect('/topup?error=' + encodeURIComponent(`Saldo tidak cukup. Saldo: ${formatRp(userInit.balance)}, Harga: ${formatRp(sellPrice)}`));

    let dest = target;
    if (product.format_order === 'zone' && zone_id) dest = `${target}(${zone_id})`;
    else if (cat === 'pulsa' || cat === 'data' || cat === 'ewallet') {
      dest = target.replace(/[^0-9]/g, '');
      if (dest.startsWith('62') && dest.length >= 10) dest = '0' + dest.substring(2);
    }
    const refID = 'TRX' + Date.now().toString().slice(-8);
    const trxId = 'H2H-' + uuidv4().split('-')[0].toUpperCase();

    // ── ATOMIC balance deduct: lock per user ──────────────────────────────────
    let origBal, user;
    try {
      const deductResult = await withLock('balance:' + userInit.id, async () => {
        const fu = await db.findUser({ id: userInit.id });
        if (!fu) throw new Error('User tidak ditemukan');
        if (fu.balance < sellPrice) return { ok: false, user: fu };
        await db.updateUser(fu.id, { balance: fu.balance - sellPrice });
        return { ok: true, origBal: fu.balance, user: fu };
      });
      if (!deductResult.ok) {
        return res.redirect('/topup?error=' + encodeURIComponent(`Saldo tidak cukup. Saldo: ${formatRp(deductResult.user.balance)}, Harga: ${formatRp(sellPrice)}`));
      }
      origBal = deductResult.origBal;
      user    = deductResult.user;
    } catch (lockErr) {
      return res.redirect('/topup?error=' + encodeURIComponent(lockErr.message));
    }

    let okeResp;
    try { okeResp = await withProviderLimit(() => oke.order(product_code, dest, refID)); }
    catch (provErr) {
      await db.updateUser(user.id, { balance: origBal });
      await db.addTransaction({ id: trxId, user_id: user.id, username: user.username, product_code, product_name: product.keterangan || product_code, category: cat, target, zone_id: zone_id || null, dest, ref_id: refID, amount: sellPrice, provider_price: parseInt(product.harga), status: 'failed', promo_code: appliedPromoCode, promo_discount: promoDiscount, provider_message: 'Provider error: ' + provErr.message, created_at: new Date().toISOString() });
      return res.redirect('/topup?error=' + encodeURIComponent('Gagal menghubungi provider: ' + provErr.message));
    }
    const status = okeResp.status;
    if (status === 'failed') await db.updateUser(user.id, { balance: origBal });
    else if (appliedPromoCode) applyPromoUsage(appliedPromoCode);
    await db.addTransaction({ id: trxId, user_id: user.id, username: user.username, product_code, product_name: product.keterangan || product_code, category: cat, target, zone_id: zone_id || null, dest, ref_id: refID, amount: sellPrice, provider_price: parseInt(product.harga), status, promo_code: appliedPromoCode, promo_discount: promoDiscount, provider_message: okeResp.message, created_at: new Date().toISOString() });
    const { password: _, ...safeUser } = await db.findUser({ id: user.id });
    req.session.user = safeUser;
    if (status === 'failed') return res.redirect('/topup?error=' + encodeURIComponent('Order gagal: ' + okeResp.message));
    if (status === 'success') incrementFlashSaleSold(product_code);
    res.redirect('/struk/' + encodeURIComponent(trxId));
  } catch (e) { res.redirect('/topup?error=' + encodeURIComponent(e.message)); }
});

// ── ORDER via QRIS (guest + logged-in) ───────
router.post('/topup/order-qris', async (req, res) => {
  const { product_code, target, zone_id, promo_code, guest_email, guest_name } = req.body;
  const isGuest = !(req.session && req.session.user);

  if (!product_code || !target)
    return res.json({ status: false, message: 'product_code dan target wajib diisi' });
  if (isGuest && (!guest_email || !guest_name))
    return res.json({ status: false, message: 'Email dan nama wajib diisi untuk pembelian tanpa login' });

  try {
    const product = findProduct(product_code);
    if (!product) return res.json({ status: false, message: 'Produk tidak ditemukan: ' + product_code });

    const cat = product.category;
    let userId = null, userRole = 'regular', userName = guest_name || 'Guest', userEmail = guest_email || '';

    if (!isGuest) {
      const user = await db.findUser({ id: req.session.user.id });
      if (!user) return res.json({ status: false, message: 'User tidak ditemukan' });
      userId    = user.id;
      userRole  = user.role;
      userName  = user.username;
      userEmail = user.email;
    }

    const sellPrice0 = calcPrice(parseInt(product.harga || 0), cat, userRole);
    let sellPrice = sellPrice0, promoDiscount = 0, appliedPromoCode = null;
    if (promo_code && promo_code.trim()) {
      const pr = validatePromo(promo_code.trim(), sellPrice, cat);
      if (pr && !pr.error) { promoDiscount = pr.discount; appliedPromoCode = promo_code.trim().toUpperCase(); sellPrice = Math.max(0, sellPrice - promoDiscount); }
    }

    let dest = target;
    if (product.format_order === 'zone' && zone_id) dest = `${target}(${zone_id})`;
    else if (cat === 'pulsa' || cat === 'data' || cat === 'ewallet') {
      dest = target.replace(/[^0-9]/g, '');
      if (dest.startsWith('62') && dest.length >= 10) dest = '0' + dest.substring(2);
    }

    // Baca QRIS fee dari config
    const cfgQris = getConfig();
    const qrisMethods = (cfgQris.payment_methods || []);
    const qrisPm = qrisMethods.find(function(m){ return m.type === 'qris'; });
    const qrisFeePct = (qrisPm && qrisPm.fee_pct) ? parseFloat(qrisPm.fee_pct) : 0;
    const qrisFeeAmount = Math.round(sellPrice * qrisFeePct / 100);
    // Kode unik 10–50 untuk identifikasi pembayaran
    const unique_code = Math.floor(Math.random() * 41) + 10;
    const amount_to_pay = sellPrice + qrisFeeAmount + unique_code;

    // Buat trxid internal yang juga dikirim ke payqris sebagai identifier
    const orderId = 'QORD-' + uuidv4().split('-')[0].toUpperCase();
    const trxId   = '#INV-' + uuidv4().split('-')[0].toUpperCase();

    // Generate QRIS via payqris.web.id
    let qrisData;
    try {
      qrisData = await createQris(amount_to_pay, orderId);
    } catch (qrisErr) {
      return res.json({ status: false, message: 'Gagal generate QRIS: ' + qrisErr.message });
    }

    const order = {
      id: orderId,
      trx_id: trxId,
      payqris_trxid: qrisData.trxid,      // trxid dari payqris untuk cek status
      type: isGuest ? 'guest' : 'user',
      user_id: userId,
      guest_email: isGuest ? guest_email : null,
      guest_name:  isGuest ? guest_name  : null,
      product_code,
      product_name: product.keterangan || product_code,
      category: cat,
      target,
      zone_id: zone_id || null,
      dest,
      amount: sellPrice,
      qris_fee_pct: qrisFeePct,
      qris_fee_amount: qrisFeeAmount,
      unique_code: unique_code,
      amount_to_pay: amount_to_pay,
      promo_code: appliedPromoCode,
      promo_discount: promoDiscount,
      qris_image: qrisData.qris_image,
      expired: qrisData.expired,
      status: 'pending',
      created_at: new Date().toISOString()
    };

    await db.addQrisOrder(order);

    // ── Simpan ke riwayat transaksi (pending_payment) ──
    try {
      await db.addTransaction({
        id: trxId,
        user_id: userId || 'guest',
        username: userName,
        product_code,
        product_name: product.keterangan || product_code,
        category: cat,
        target,
        zone_id: zone_id || null,
        dest,
        ref_id: null,
        amount: sellPrice,
        amount_to_pay,
        provider_price: parseInt(product.harga || 0),
        status: 'pending_payment',
        promo_code: appliedPromoCode,
        promo_discount: promoDiscount,
        payment_method: 'qris',
        order_id: orderId,
        guest_email: isGuest ? guest_email : null,
        guest_name:  isGuest ? guest_name  : null,
        created_at: new Date().toISOString()
      });
    } catch (trxErr) {
      console.error('[order-qris] addTransaction(pending) error:', trxErr.message);
    }

    // ── Guest: simpan ke anon_orders.json ──
    if (isGuest) {
      try {
        const anonPath = path.join(__dirname, '../data/anon_orders.json');
        const anonList = fs.existsSync(anonPath) ? JSON.parse(fs.readFileSync(anonPath, 'utf8')) : [];
        if (!anonList.find(a => a.trx_id === trxId)) {
          anonList.unshift({
            trx_id: trxId, order_id: orderId,
            product_name: product.keterangan || product_code, product_code,
            category: cat, target, zone_id: zone_id || null,
            amount: sellPrice, unique_code, amount_paid: amount_to_pay,
            payment_method: 'qris', status: 'pending_payment',
            guest_name, guest_email, ref_id: null,
            created_at: new Date().toISOString()
          });
          if (!fs.existsSync(path.join(__dirname, '../data')))
            fs.mkdirSync(path.join(__dirname, '../data'), { recursive: true });
          fs.writeFileSync(anonPath, JSON.stringify(anonList.slice(0, 5000), null, 2));
        }
      } catch (anonErr) {
        console.error('[anon_orders] init write error:', anonErr.message);
      }
    }

    res.json({
      status: true,
      order_id: orderId,
      qris_image: qrisData.qris_image,
      unique_code: unique_code,
      amount_to_pay: amount_to_pay,
      expired: qrisData.expired
    });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ── QRIS CHECK ────────────────────────────────
router.post('/topup/qris-check', async (req, res) => {
  const { order_id } = req.body;
  if (!order_id) return res.json({ status: false, message: 'order_id diperlukan' });

  try {
    const order = await db.findQrisOrder(order_id);
    if (!order) return res.json({ status: false, message: 'Order tidak ditemukan' });

    // Status final — langsung return
    if (order.status === 'success') {
      return res.json({ status: true, result: { status: 'success', trx_id: order.trx_id || null, message: 'Pembayaran berhasil!' } });
    }
    if (order.status === 'failed')    return res.json({ status: true, result: { status: 'failed',    message: 'Order gagal.' } });
    if (order.status === 'expired')   return res.json({ status: true, result: { status: 'expired',   message: 'QRIS sudah kadaluarsa.' } });
    if (order.status === 'cancelled') return res.json({ status: true, result: { status: 'cancelled', message: 'Order dibatalkan.' } });

    // Cek expiry lokal
    if (new Date(order.expired) < new Date()) {
      await db.updateQrisOrder(order_id, { status: 'expired' });
      if (order.trx_id) { try { await db.updateTransaction(order.trx_id, { status: 'expired', updated_at: new Date().toISOString() }); } catch {} }
      if (order.payqris_trxid) cancelQris(order.payqris_trxid).catch(() => {});
      return res.json({ status: true, result: { status: 'expired', message: 'QRIS sudah kadaluarsa.' } });
    }

    // Safety: tidak ada payqris_trxid
    if (!order.payqris_trxid) {
      return res.json({ status: true, result: { status: 'pending', message: 'Menunggu konfirmasi pembayaran...' } });
    }

    // ── Cek status via payqris API ───────────────────────────────────────────
    let apiStatus;
    try {
      const apiResp = await checkQrisStatus(order.payqris_trxid);
      apiStatus = (apiResp.txStatus || '').toLowerCase();
    } catch (apiErr) {
      console.error('[qris-check] checkQrisStatus error:', apiErr.message);
      return res.json({ status: true, result: { status: 'pending', message: 'Menunggu konfirmasi pembayaran...' } });
    }

    if (apiStatus !== 'sukses') {
      return res.json({ status: true, result: { status: 'pending', message: 'Menunggu pembayaran...' } });
    }

    // ── ATOMIC EXECUTION GUARD: cegah double-execute ─────────────────────────
    const execResult = await db.executeQrisOrderIfPending(order_id);
    if (!execResult.executed) {
      const st = execResult.reason;
      if (st === 'success' || st === 'processing') {
        return res.json({ status: true, result: { status: 'success', trx_id: execResult.order?.trx_id || order.trx_id || null, message: 'Order sudah diproses.' } });
      }
      return res.json({ status: true, result: { status: st || 'pending', message: 'Order sedang diproses.' } });
    }

    // ── Eksekusi ke provider ─────────────────────────────────────────────────
    const product = findProduct(order.product_code);
    const refID   = 'TRX' + Date.now().toString().slice(-8);
    const trxId   = order.trx_id || ('H2H-' + uuidv4().split('-')[0].toUpperCase());
    let okeStatus = 'process', okeMsg = '';

    try {
      const okeResp = await withProviderLimit(() => oke.order(order.product_code, order.dest, refID));
      okeStatus = okeResp.status || 'process';
      okeMsg    = okeResp.message || '';
    } catch (e) { okeStatus = 'failed'; okeMsg = e.message; }

    if (order.promo_code) applyPromoUsage(order.promo_code);

    // Update transaksi yang sudah tersimpan (pending_payment → status final)
    if (order.trx_id) {
      try {
        await db.updateTransaction(trxId, {
          status: okeStatus, ref_id: refID,
          provider_price: parseInt(product?.harga || 0),
          provider_message: okeMsg, payment_method: 'qris',
          executed_at: new Date().toISOString(), updated_at: new Date().toISOString()
        });
      } catch (updErr) {
        console.error('[qris-check] updateTransaction error, fallback:', updErr.message);
        await db.addTransaction({
          id: trxId, user_id: order.user_id || 'guest', username: order.guest_name || 'Guest',
          product_code: order.product_code, product_name: order.product_name,
          category: order.category, target: order.target, zone_id: order.zone_id,
          dest: order.dest, ref_id: refID, amount: order.amount,
          provider_price: parseInt(product?.harga || 0), status: okeStatus,
          promo_code: order.promo_code, promo_discount: order.promo_discount,
          provider_message: okeMsg, payment_method: 'qris',
          guest_email: order.guest_email, guest_name: order.guest_name,
          created_at: new Date().toISOString()
        });
      }
    } else {
      await db.addTransaction({
        id: trxId, user_id: order.user_id || 'guest', username: order.guest_name || 'Guest',
        product_code: order.product_code, product_name: order.product_name,
        category: order.category, target: order.target, zone_id: order.zone_id,
        dest: order.dest, ref_id: refID, amount: order.amount,
        provider_price: parseInt(product?.harga || 0), status: okeStatus,
        promo_code: order.promo_code, promo_discount: order.promo_discount,
        provider_message: okeMsg, payment_method: 'qris',
        guest_email: order.guest_email, guest_name: order.guest_name,
        created_at: new Date().toISOString()
      });
    }

    await db.finalizeQrisOrder(order_id, {
      status: 'success', trx_id: trxId, ref_id: refID,
      oke_status: okeStatus, finalized_at: new Date().toISOString(),
    });
    if (okeStatus === 'success') incrementFlashSaleSold(order.product_code);

    // Update anon_orders.json jika guest
    if (!order.user_id || order.user_id === 'guest') {
      try {
        const anonPath = path.join(__dirname, '../data/anon_orders.json');
        const anonList = fs.existsSync(anonPath) ? JSON.parse(fs.readFileSync(anonPath, 'utf8')) : [];
        const anonIdx  = anonList.findIndex(a => a.trx_id === trxId || a.order_id === order_id);
        if (anonIdx !== -1) {
          anonList[anonIdx] = { ...anonList[anonIdx], status: okeStatus, ref_id: refID, executed_at: new Date().toISOString() };
        } else {
          anonList.unshift({
            trx_id: trxId, order_id: order_id, product_name: order.product_name,
            product_code: order.product_code, category: order.category, target: order.target,
            zone_id: order.zone_id || null, amount: order.amount, unique_code: order.unique_code || 0,
            amount_paid: order.amount_to_pay || order.amount, payment_method: 'qris',
            status: okeStatus, ref_id: refID, guest_name: order.guest_name || null,
            guest_email: order.guest_email || null, created_at: new Date().toISOString()
          });
        }
        if (!fs.existsSync(path.join(__dirname, '../data')))
          fs.mkdirSync(path.join(__dirname, '../data'), { recursive: true });
        fs.writeFileSync(anonPath, JSON.stringify(anonList.slice(0, 5000), null, 2));
      } catch (anonErr) {
        console.error('[anon_orders] write error:', anonErr.message);
      }
    }

    // Kirim struk email
    const emailTo = order.guest_email || (order.user_id ? (await db.findUser({ id: order.user_id }))?.email : null);
    if (emailTo) {
      sendOrderReceiptEmail(emailTo, {
        trxid: trxId, product_name: order.product_name,
        target: order.target, amount: order.amount,
        status: okeStatus, created_at: new Date().toISOString(),
        guest_name: order.guest_name
      }).catch(() => {});
    }

    res.json({
      status: true,
      result: {
        status: okeStatus === 'failed' ? 'success_paid_failed_order' : 'success',
        trx_id: trxId,
        message: okeStatus === 'failed' ? 'Pembayaran diterima tapi order gagal. Hubungi admin.' : 'Pembayaran & order berhasil!'
      }
    });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ── QRIS CANCEL ───────────────────────────────
router.post('/topup/qris-cancel', async (req, res) => {
  const { order_id } = req.body;
  if (!order_id) return res.json({ status: false, message: 'order_id diperlukan' });

  try {
    const order = await db.findQrisOrder(order_id);
    if (!order) return res.json({ status: false, message: 'Order tidak ditemukan' });

    if (order.status !== 'pending') {
      return res.json({ status: false, message: 'Hanya order pending yang bisa dibatalkan (status saat ini: ' + order.status + ')' });
    }

    await db.updateQrisOrder(order_id, { status: 'cancelled', cancelled_at: new Date().toISOString() });
    if (order.trx_id) {
      try { await db.updateTransaction(order.trx_id, { status: 'cancelled', updated_at: new Date().toISOString() }); } catch {}
    }
    return res.json({ status: true, message: 'Order berhasil dibatalkan' });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

// ── QRIS Page (standalone) ───────────────────
router.get('/topup/qris/:orderId', async (req, res) => {
  const order = await db.findQrisOrder(req.params.orderId);
  if (!order) return res.redirect('/topup?error=' + encodeURIComponent('Order tidak ditemukan'));
  res.render('topup-qris', {
    user: req.session?.user || null,
    order,
    layout: 'layout'
  });
});

// ── STRUK / RECEIPT ───────────────────────────
router.get('/struk/:trxId', async (req, res) => {
  const trxId = req.params.trxId;
  try {
    const { transactions } = await db.getTransactions();
    const trx = transactions.find(t => t.id === trxId);
    if (!trx) return res.redirect('/lacak?error=' + encodeURIComponent('Transaksi tidak ditemukan: ' + trxId));
    let qrisOrder = null;
    try {
      const { orders } = await db.getQrisOrders();
      qrisOrder = (orders || []).find(o => o.trx_id === trxId) || null;
    } catch {}
    res.render('struk', {
      user: (req.session && req.session.user) || null,
      trx, qrisOrder, config: getConfig(), title: 'Struk ' + trxId
    });
  } catch (e) {
    res.redirect('/lacak?error=' + encodeURIComponent(e.message));
  }
});

// ── STRUK CHECK (status re-check + OKEConnect sync) ──
router.post('/struk-check', express.json(), async (req, res) => {
  const { trx_id } = req.body;
  if (!trx_id) return res.json({ status: 'error', message: 'trx_id diperlukan' });
  try {
    const { transactions } = await db.getTransactions();
    const trx = transactions.find(t => t.id === trx_id);
    if (!trx) return res.json({ status: 'error', message: 'Transaksi tidak ditemukan' });

    // Jika status sudah final, langsung return
    if (trx.status === 'success' || trx.status === 'failed') {
      return res.json({ status: trx.status, message: trx.provider_message || '' });
    }

    // Status masih pending/process → cek ulang ke OKEConnect
    if (trx.ref_id) {
      try {
        const dest = trx.dest || trx.target || '';
        const okeResult = await oke.checkStatus(trx.product_code, dest, trx.ref_id);
        if (okeResult.status === 'success' || okeResult.status === 'failed') {
          // Update DB supaya status tersimpan
          try {
            await db.updateTransaction(trx_id, {
              status: okeResult.status,
              provider_message: okeResult.message,
              updated_at: new Date().toISOString()
            });
            // Update anon_orders.json jika ini guest order
            if (!trx.user_id || trx.user_id === 'guest') {
              try {
                const anonPath = path.join(__dirname, '../data/anon_orders.json');
                const anonList = fs.existsSync(anonPath) ? JSON.parse(fs.readFileSync(anonPath, 'utf8')) : [];
                const ai = anonList.findIndex(o => o.trx_id === trx_id);
                if (ai !== -1) {
                  anonList[ai].status = okeResult.status;
                  anonList[ai].updated_at = new Date().toISOString();
                  fs.writeFileSync(anonPath, JSON.stringify(anonList, null, 2));
                }
              } catch {}
            }
          } catch {}
          return res.json({ status: okeResult.status, message: okeResult.message });
        }
        // OKEConnect masih pending/process
        return res.json({ status: okeResult.status || trx.status, message: okeResult.message || trx.provider_message || '' });
      } catch (okeErr) {
        // Jika OKEConnect error, return status DB saja
      }
    }

    res.json({ status: trx.status, message: trx.provider_message || '' });
  } catch (e) {
    res.json({ status: 'error', message: e.message });
  }
});

// ── LACAK TRANSAKSI ────────────────────────────
router.get('/lacak', async (req, res) => {
  const query = req.query.id || '';
  if (query.trim()) return res.redirect('/struk/' + encodeURIComponent(query.trim()));
  let recentTrx = [];
  if (req.session && req.session.user) {
    try {
      const { transactions } = await db.getTransactions();
      recentTrx = transactions
        .filter(function(t){ return t.status === 'success'; })
        .slice(0, 10)
        .map(function(t){
          var tid = String(t.id || '');
          var maskedId = tid.length > 8 ? tid.substring(0,4) + 'x'.repeat(Math.max(0,tid.length-8)) + tid.slice(-4) : tid;
          var tgt = String(t.target || '');
          var maskedTarget = tgt.length > 3 ? '*'.repeat(Math.max(0,tgt.length-3)) + tgt.slice(-3) : tgt;
          return { created_at:t.created_at, id:maskedId, target:maskedTarget, amount:t.amount||0, status:t.status };
        });
    } catch(e) {}
  }
  res.render('lacak', {
    user: (req.session && req.session.user) || null,
    query: '',
    recentTrx: recentTrx,
    error: req.query.error || null,
    config: getConfig(), title: 'Cek Transaksi'
  });
});

// ── Deposit, Docs, Reseller (unchanged) ──────
router.get('/deposit', authMiddleware, async (req, res) => {
  const { deposits } = await db.getDeposits();
  const myDeposits = deposits.filter(d => d.user_id === req.session.user.id).slice(0, 10);
  const cfg = getConfig();
  res.render('deposit', {
    user: req.session.user, deposits: myDeposits,
    minDeposit: cfg.deposit ? cfg.deposit.min || 10000 : 10000,
    error: req.query.error || null, success: req.query.success || null
  });
});

router.get('/docs', (req, res) => {
  res.render('docs', { user: req.session ? req.session.user || null : null, config: getConfig() });
});

router.get('/informasi', (req, res) => {
  const infoPath = path.join(__dirname, '../data/informasi.json');
  let informasi = [];
  try { if (fs.existsSync(infoPath)) informasi = JSON.parse(fs.readFileSync(infoPath, 'utf-8')); } catch {}
  const activeInfos = informasi.filter(i => i.active !== false);
  res.render('informasi', {
    user: req.session ? req.session.user || null : null,
    informasi: activeInfos
  });
});

router.get('/informasi/:id', (req, res) => {
  const infoPath = path.join(__dirname, '../data/informasi.json');
  let informasi = [];
  try { if (fs.existsSync(infoPath)) informasi = JSON.parse(fs.readFileSync(infoPath, 'utf-8')); } catch {}
  const item = informasi.find(i => i.id === req.params.id && i.active !== false);
  if (!item) return res.redirect('/informasi');
  res.render('informasi-detail', { user: req.session ? req.session.user || null : null, item });
});

// replaced by bot-aware reseller GET below

// ── MANUAL TRANSFER ORDER ────────────────────────
router.post('/topup/order-manual', async (req, res) => {
  const { product_code, target, zone_id, promo_code, guest_email, guest_name,
          payment_method_id, payment_method_name, payment_method_type } = req.body;
  const isGuest = !(req.session && req.session.user);

  if (!product_code || !target)
    return res.json({ status: false, message: 'product_code dan target wajib diisi' });
  if (!payment_method_id)
    return res.json({ status: false, message: 'Metode pembayaran tidak dipilih' });

  try {
    const product = findProduct(product_code);
    if (!product) return res.json({ status: false, message: 'Produk tidak ditemukan: ' + product_code });

    const cat = product.category;
    let userId = null, userRole = 'regular', userName = guest_name || 'Guest', userEmail = guest_email || '';

    if (!isGuest) {
      const user = await db.findUser({ id: req.session.user.id });
      if (!user) return res.json({ status: false, message: 'User tidak ditemukan' });
      userId   = user.id;
      userRole = user.role;
      userName = user.username;
      userEmail = user.email;
    }

    const sellPrice0 = calcPrice(parseInt(product.harga || 0), cat, userRole);
    let sellPrice = sellPrice0, promoDiscount = 0, appliedPromoCode = null;
    if (promo_code && promo_code.trim()) {
      const pr = validatePromo ? validatePromo(promo_code.trim(), sellPrice, cat) : null;
      if (pr && !pr.error) { promoDiscount = pr.discount; appliedPromoCode = promo_code.trim().toUpperCase(); sellPrice = Math.max(0, sellPrice - promoDiscount); }
    }

    // Fee from payment method config
    const cfg = getConfig();
    const pmethods = (cfg.payment_methods || []);
    const pm = pmethods.find(function(m){ return m.id === payment_method_id; });
    const feePct = (pm && pm.fee_pct) ? parseFloat(pm.fee_pct) : 0;
    const feeAmount = Math.round(sellPrice * feePct / 100);
    const amountToPay = sellPrice + feeAmount;

    let dest = target;
    if (product.format_order === 'zone' && zone_id) dest = target + '(' + zone_id + ')';

    const orderId = 'MORD-' + uuidv4().split('-')[0].toUpperCase();
    const trxId   = 'H2H-' + uuidv4().split('-')[0].toUpperCase();

    try {
      await db.addTransaction({
        id: trxId,
        user_id: userId || 'guest',
        username: userName,
        product_code,
        product_name: product.keterangan || product_code,
        category: cat,
        target,
        zone_id: zone_id || null,
        dest,
        ref_id: null,
        amount: sellPrice,
        amount_to_pay: amountToPay,
        provider_price: parseInt(product.harga || 0),
        status: 'pending_payment',
        promo_code: appliedPromoCode,
        promo_discount: promoDiscount,
        payment_method: payment_method_id,
        payment_method_name: payment_method_name || payment_method_id,
        order_id: orderId,
        guest_email: isGuest ? guest_email : null,
        guest_name:  isGuest ? guest_name  : null,
        created_at: new Date().toISOString()
      });
    } catch (trxErr) {
      console.error('[order-manual] addTransaction error:', trxErr.message);
    }

    res.json({
      status: true,
      order_id: orderId,
      trx_id: trxId,
      amount: sellPrice,
      fee: feeAmount,
      amount_to_pay: amountToPay,
      payment_method_id,
      payment_method_name: pm ? pm.nama : payment_method_name,
      norek: pm ? (pm.norek || '') : '',
      nama_penerima: pm ? (pm.nama_penerima || '') : '',
      max_time: pm ? (pm.max_time || 60) : 60,
      message: 'Order berhasil dibuat, silakan transfer'
    });
  } catch (e) {
    res.json({ status: false, message: e.message });
  }
});

router.post('/reseller/join', authMiddleware, async (req, res) => {
  try {
    const cfg   = getConfig();
    const price = cfg.reseller ? cfg.reseller.join_price || 50000 : 50000;
    const user  = await db.findUser({ id: req.session.user.id });
    if (user.role === 'reseller' || user.role === 'admin') return res.redirect('/reseller?error=Sudah+jadi+reseller');
    if (user.balance < price) return res.redirect('/reseller?error=Saldo+tidak+cukup');
    await db.updateUser(user.id, { role: 'reseller', balance: user.balance - price, reseller_since: new Date().toISOString() });
    const { password: _, ...updated } = await db.findUser({ id: user.id });
    req.session.user = updated;
    res.redirect('/reseller?success=Selamat!+Kamu+sekarang+menjadi+Reseller');
  } catch (e) { res.redirect('/reseller?error=' + encodeURIComponent(e.message)); }
});


// ── LEADERBOARD ───────────────────────────────────────────────────────────
router.get('/leaderboard', optionalAuth, async (req, res) => {
  try {
    const cfg = getConfig();
    const siteName = (cfg.branding && cfg.branding.site_name) || 'H2H Store';

    const { transactions } = await db.getTransactions();
    const { users } = await db.getUsers();

    // Build map userId → username (exclude admin)
    const userMap = {};
    users.forEach(function(u) {
      if (u.role !== 'admin') userMap[u.id] = u.username || u.email || ('User#' + u.id);
    });

    // Count successful orders per non-admin user
    const counts = {};
    transactions.forEach(function(t) {
      if (t.user_id && userMap[t.user_id] && t.status === 'success') {
        counts[t.user_id] = (counts[t.user_id] || 0) + 1;
      }
    });

    const leaderboard = Object.entries(counts)
      .map(function(entry) { return { username: userMap[entry[0]], count: entry[1] }; })
      .sort(function(a, b) { return b.count - a.count; })
      .slice(0, 50);

    res.render('leaderboard', {
      user: req.session.user || null,
      leaderboard,
      siteConfig: cfg,
      siteName,
      error: null,
      success: null,
      unreadCount: 0,
      banners: []
    });
  } catch (e) {
    res.redirect('/?error=' + encodeURIComponent(e.message));
  }
});

// ── KALKULATOR ────────────────────────────────────────────────────────────
router.get('/kalkulator', optionalAuth, (req, res) => {
  try {
    const cfg = getConfig();
    const siteName = (cfg.branding && cfg.branding.site_name) || 'H2H Store';

    // Build profit config for frontend
    const profitCfg = {};
    const cats = ['game','pulsa','data','ewallet','tagihan','digital','streaming'];
    cats.forEach(function(cat) {
      profitCfg[cat] = cfg.profit && cfg.profit[cat] ? cfg.profit[cat] : { type: 'flat', value: 0 };
    });
    profitCfg.reseller = {};
    cats.forEach(function(cat) {
      profitCfg.reseller[cat] = cfg.reseller && cfg.reseller.profit && cfg.reseller.profit[cat]
        ? cfg.reseller.profit[cat]
        : (cfg.profit && cfg.profit[cat] ? cfg.profit[cat] : { type: 'flat', value: 0 });
    });

    res.render('kalkulator', {
      user: req.session.user || null,
      profitCfg,
      siteConfig: cfg,
      siteName,
      error: null,
      success: null,
      unreadCount: 0,
      banners: []
    });
  } catch (e) {
    res.redirect('/?error=' + encodeURIComponent(e.message));
  }
});


// ── RESELLER: BOT CREATION & CONFIG ──────────────────────────────────────

// Helper: pastikan user punya apikey di DB, return apikey-nya
async function ensureUserApiKey(user) {
  if (user.apikey) return user.apikey;
  // Belum punya → generate & simpan dulu
  const newKey = generateApiKey();
  await db.updateUser(user.id, { apikey: newKey });
  return newKey;
}

// Helper: redirect ke reseller dengan error
function resellerErr(res, msg) {
  return res.redirect('/reseller?error=' + encodeURIComponent(msg));
}

// ── GET /reseller ─────────────────────────────────────────────────────────
router.get('/reseller', authMiddleware, (req, res) => {
  const cfg = getConfig();
  const bots = botManager.readBots();
  const myBot = bots.find(b => b.owner_user_id === String(req.session.user.id)) || null;
  const botStatus = myBot ? (botManager.getStatus()[myBot.id] ? 'running' : 'stopped') : null;
  const editMode = req.query.edit === '1' && !!myBot;
  res.render('reseller', {
    user: req.session.user,
    joinPrice: cfg.reseller ? cfg.reseller.join_price || 50000 : 50000,
    config: cfg, myBot, botStatus, editMode,
    error: req.query.error || null,
    success: req.query.success || null
  });
});

// ── POST /reseller/create-bot ─────────────────────────────────────────────
router.post('/reseller/create-bot', authMiddleware, async (req, res) => {
  try {
    const user = await db.findUser({ id: req.session.user.id });
    if (!user)                                               return resellerErr(res, 'User tidak ditemukan');
    if (user.role !== 'reseller' && user.role !== 'admin')  return resellerErr(res, 'Hanya reseller yang bisa membuat bot');

    const { bot_token, bot_name, bot_thumb, owner_tg_id, owner_name, active } = req.body;
    if (!bot_token || !bot_name || !owner_tg_id || !owner_name)
      return resellerErr(res, 'Nama bot, token, ID Telegram, dan nama owner wajib diisi');

    const bots = botManager.readBots();

    // Cek sudah punya bot
    if (bots.find(b => b.owner_user_id === String(user.id)))
      return resellerErr(res, 'Kamu sudah punya 1 bot. Minta admin hapus bot lama jika ingin ganti.');

    // Cek token duplikat
    if (bots.find(b => b.token === bot_token.trim()))
      return resellerErr(res, 'Token sudah dipakai bot lain');

    // ── KUNCI: api_key harus = user.apikey di DB agar bot bisa credit saldo ──
    const siteApiKey = await ensureUserApiKey(user);

    const expAt = new Date();
    expAt.setMonth(expAt.getMonth() + 1);

    const newBot = {
      id:             require('uuid').v4(),
      name:           bot_name.trim(),
      token:          bot_token.trim(),
      owner_user_id:  String(user.id),
      owner_id:       owner_tg_id.trim(),
      owner_username: user.username,
      owner_name:     owner_name.trim(),
      api_key:        siteApiKey,           // ← pakai apikey user yang terdaftar di DB
      thumb:          (bot_thumb || '').trim() || null,
      expired_at:     expAt.toISOString().slice(0, 10),
      active:         active === '1',
      created_at:     new Date().toISOString()
    };

    bots.push(newBot);
    botManager.writeBots(bots);
    if (newBot.active) botManager.startBot(newBot);

    res.redirect('/reseller?success=' + encodeURIComponent('Bot "' + newBot.name + '" berhasil dibuat dan sudah aktif!'));
  } catch (e) { resellerErr(res, e.message); }
});

// ── POST /reseller/edit-bot ───────────────────────────────────────────────
router.post('/reseller/edit-bot', authMiddleware, async (req, res) => {
  try {
    const user = await db.findUser({ id: req.session.user.id });
    if (!user) return resellerErr(res, 'User tidak ditemukan');

    const { bot_token, bot_name, bot_thumb, owner_tg_id, owner_name, active } = req.body;
    if (!bot_token || !bot_name || !owner_tg_id || !owner_name)
      return resellerErr(res, 'Semua field wajib diisi');

    if (!/^d+:[w-]{35,}$/.test(bot_token.trim()))
      return resellerErr(res, 'Format token tidak valid');

    const bots = botManager.readBots();
    const idx  = bots.findIndex(b => b.owner_user_id === String(user.id));
    if (idx === -1) return resellerErr(res, 'Bot tidak ditemukan');

    // Cek token duplikat (kecuali token milik bot sendiri)
    const dupToken = bots.find(b => b.token === bot_token.trim() && b.id !== bots[idx].id);
    if (dupToken) return resellerErr(res, 'Token sudah dipakai bot lain');

    const siteApiKey = await ensureUserApiKey(user);
    const wasActive  = bots[idx].active;

    bots[idx] = {
      ...bots[idx],
      name:       bot_name.trim(),
      token:      bot_token.trim(),
      owner_id:   owner_tg_id.trim(),
      owner_name: owner_name.trim(),
      api_key:    siteApiKey,
      thumb:      (bot_thumb || '').trim() || null,
      active:     active === '1',
      updated_at: new Date().toISOString()
    };

    botManager.writeBots(bots);
    // Restart bot supaya config baru berlaku
    if (wasActive) botManager.stopBot(bots[idx].id);
    if (bots[idx].active) botManager.startBot(bots[idx]);

    res.redirect('/reseller?success=' + encodeURIComponent('Bot berhasil diperbarui!'));
  } catch (e) { resellerErr(res, e.message); }
});

// ── POST /reseller/stop-bot ───────────────────────────────────────────────
router.post('/reseller/stop-bot', authMiddleware, async (req, res) => {
  try {
    const user = await db.findUser({ id: req.session.user.id });
    if (!user) return resellerErr(res, 'User tidak ditemukan');
    const bots  = botManager.readBots();
    const myBot = bots.find(b => b.owner_user_id === String(user.id));
    if (!myBot) return resellerErr(res, 'Bot tidak ditemukan');
    botManager.stopBot(myBot.id);
    botManager.writeBots(bots.map(b => b.id === myBot.id ? { ...b, active: false } : b));
    res.redirect('/reseller?success=Bot dihentikan');
  } catch (e) { resellerErr(res, e.message); }
});

// ── POST /reseller/start-bot ──────────────────────────────────────────────
router.post('/reseller/start-bot', authMiddleware, async (req, res) => {
  try {
    const user = await db.findUser({ id: req.session.user.id });
    if (!user) return resellerErr(res, 'User tidak ditemukan');
    const bots  = botManager.readBots();
    const myBot = bots.find(b => b.owner_user_id === String(user.id));
    if (!myBot) return resellerErr(res, 'Bot tidak ditemukan');
    botManager.writeBots(bots.map(b => b.id === myBot.id ? { ...b, active: true } : b));
    botManager.startBot({ ...myBot, active: true });
    res.redirect('/reseller?success=Bot dinyalakan kembali');
  } catch (e) { resellerErr(res, e.message); }
});

module.exports = router;
