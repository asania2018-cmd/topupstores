const express = require('express');
const router  = express.Router();
const path    = require('path');
const fs      = require('fs');
const db      = require('../lib/github-db');
const oke     = require('../lib/okeconnect');
const { adminMiddleware, generateApiKey, createUser, checkPassword } = require('../lib/auth');
const {
  readProducts, saveProducts, getAllCategories, getCategoryOrder, saveCategoryOrder,
  getGameCategories, saveGameCategories,
  addProduct, editProduct, deleteProduct, reorderProducts,
  addVariant, editVariant, deleteVariant, reorderVariants,
  addItem, editItem, deleteItem, toggleItem, reorderItems,
  findProduct
} = require('../lib/products');
const { getConfig, saveConfig, getDefaultConfig } = require('../lib/pricing');

// ── helpers ──────────────────────────────────
function readJson(p, d) {
  try { if (!fs.existsSync(p)) return d; return JSON.parse(fs.readFileSync(p, 'utf-8')); }
  catch { return d; }
}
function writeJson(p, data) {
  const dir = path.dirname(p);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(p, JSON.stringify(data, null, 2), 'utf-8');
}
const BannersPath  = () => path.join(__dirname, '../data/banners.json');
const FlashPath    = () => path.join(__dirname, '../data/flashsale.json');
const PopupsPath   = () => path.join(__dirname, '../data/popups.json');
const PlansPath    = () => path.join(__dirname, '../data/reseller-plans.json');
const PromoPath    = () => path.join(__dirname, '../data/promo.json');
function nanoid() { return Date.now().toString(36) + Math.random().toString(36).slice(2,7); }
function slugify(s) { return (s||'').toLowerCase().replace(/\s+/g,'-').replace(/[^a-z0-9-]/g,''); }

// ── ADMIN LOGIN (no auth) ─────────────────────
router.get('/login', (req, res) => {
  if (req.session?.user?.role === 'admin') return res.redirect('/admin');
  res.render('admin/login', { user: null, error: req.query.error ? decodeURIComponent(req.query.error) : null, title: 'Admin Login' });
});
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await db.findUser({ username });
    if (!user) return res.render('admin/login', { user: null, error: 'Username tidak ditemukan', title: 'Admin Login' });
    if (user.role !== 'admin') return res.render('admin/login', { user: null, error: 'Bukan admin', title: 'Admin Login' });
    if (!(await checkPassword(password, user.password))) return res.render('admin/login', { user: null, error: 'Password salah', title: 'Admin Login' });
    const { password: _, ...safe } = user;
    req.session.user = safe;
    res.redirect('/admin');
  } catch (e) { res.render('admin/login', { user: null, error: e.message, title: 'Admin Login' }); }
});

router.use(adminMiddleware);

// ── DASHBOARD ────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const { users }        = await db.getUsers();
    const { transactions } = await db.getTransactions();
    const { deposits }     = await db.getDeposits();
    const totalRevenue = transactions.filter(t => t.status === 'success').reduce((s, t) => s + (t.amount || 0), 0);
    res.render('admin/index', {
      user: req.user,
      stats: {
        totalUsers: users.length,
        totalTrx:   transactions.length,
        successTrx: transactions.filter(t => t.status === 'success').length,
        pendingTrx: transactions.filter(t => t.status === 'pending').length,
        totalRevenue,
        pendingDeposits: deposits.filter(d => d.status === 'pending').length
      },
      recentTrx: transactions.slice(0, 10),
      error: req.query.error ? decodeURIComponent(req.query.error) : null,
      success: req.query.success ? decodeURIComponent(req.query.success) : null
    });
  } catch (e) { res.render('admin/index', { user: req.user, stats: {}, recentTrx: [], error: e.message, success: null }); }
});

// ── USERS ────────────────────────────────────
router.get('/users', async (req, res) => {
  try {
    const { users } = await db.getUsers();
    res.render('admin/users', {
      user: req.user,
      users: users.map(u => { const { password, ...s } = u; return s; }),
      error: req.query.error || null, success: req.query.success || null
    });
  } catch (e) { res.render('admin/users', { user: req.user, users: [], error: e.message, success: null }); }
});
router.post('/users/create', async (req, res) => {
  const { username, email, password, role } = req.body;
  try { await createUser({ username, email, password, role: role || 'regular' }); res.redirect('/admin/users?success=User+berhasil+dibuat'); }
  catch (e) { res.redirect('/admin/users?error=' + encodeURIComponent(e.message)); }
});
router.post('/users/update', async (req, res) => {
  const { user_id, role, balance, action } = req.body;
  try {
    if (action === 'reset_apikey') await db.updateUser(user_id, { apikey: generateApiKey() });
    else if (action === 'update_balance') await db.updateUser(user_id, { balance: parseFloat(balance) || 0 });
    else if (action === 'update_role') await db.updateUser(user_id, { role });
    else if (action === 'topup') {
      const u = await db.findUser({ id: user_id });
      await db.updateUser(user_id, { balance: (u.balance || 0) + (parseFloat(balance) || 0) });
    }
    res.redirect('/admin/users?success=User+diperbarui');
  } catch (e) { res.redirect('/admin/users?error=' + encodeURIComponent(e.message)); }
});
router.post('/users/delete', async (req, res) => {
  const { user_id } = req.body;
  try {
    const { users, sha } = await db.getUsers();
    await db.saveUsers(users.filter(u => u.id !== user_id), sha);
    res.redirect('/admin/users?success=User+dihapus');
  } catch (e) { res.redirect('/admin/users?error=' + encodeURIComponent(e.message)); }
});

// ── RESELLER PLANS ───────────────────────────
router.get('/reseller-plans', (req, res) => {
  let plans = readJson(PlansPath(), []);
  if (!plans.length) {
    plans = [
      { id:'monthly', name:'Bulanan', price:50000, duration:30, featured:false, benefits:['Harga lebih murah','Akses semua produk H2H','Support prioritas'] },
      { id:'quarterly', name:'3 Bulan', price:130000, duration:90, featured:true, benefits:['Hemat 13%','Harga lebih murah','Akses semua produk H2H','Badge Reseller Aktif'] },
      { id:'yearly', name:'Tahunan', price:450000, duration:365, featured:false, benefits:['Hemat 25%','Harga terbaik','Akses semua produk','Badge Reseller Premium'] }
    ];
    writeJson(PlansPath(), plans);
  }
  res.render('admin/reseller-plans', { user: req.user, plans, error: req.query.error||null, success: req.query.success||null });
});
router.post('/reseller-plans/save', (req, res) => {
  try {
    let plans = readJson(PlansPath(), []);
    const { plan_id, id, name, price, duration, benefits, featured } = req.body;
    const bList = (benefits||'').split('\n').map(b=>b.trim()).filter(Boolean);
    const pSlug = id ? slugify(id) : slugify(name)+'-'+Date.now().toString(36);
    if (plan_id) {
      const idx = plans.findIndex(p => p.id === plan_id);
      if (idx !== -1) plans[idx] = { id: id||plans[idx].id, name, price: parseInt(price)||0, duration: parseInt(duration)||30, featured: featured==='1', benefits: bList };
      else plans.push({ id: pSlug, name, price: parseInt(price)||0, duration: parseInt(duration)||30, featured: featured==='1', benefits: bList });
    } else { plans.push({ id: pSlug, name, price: parseInt(price)||0, duration: parseInt(duration)||30, featured: featured==='1', benefits: bList }); }
    writeJson(PlansPath(), plans);
    res.redirect('/admin/reseller-plans?success=Paket+disimpan');
  } catch (e) { res.redirect('/admin/reseller-plans?error='+encodeURIComponent(e.message)); }
});
router.post('/reseller-plans/delete', (req, res) => {
  try { writeJson(PlansPath(), readJson(PlansPath(),[]).filter(p=>p.id!==req.body.plan_id)); res.redirect('/admin/reseller-plans?success=Paket+dihapus'); }
  catch (e) { res.redirect('/admin/reseller-plans?error='+encodeURIComponent(e.message)); }
});

// ── PRODUCTS — redirect to first cat ──────────
router.get('/products', (req, res) => res.redirect('/admin/products/game'));

// ── PRODUCTS — per category page ──────────────
router.get('/products/:cat', (req, res) => {
  const categories = getAllCategories();
  const cat = req.params.cat;
  if (!categories.includes(cat)) return res.redirect('/admin/products/game');
  const products = {};
  products[cat] = readProducts(cat);
  res.render('admin/products', {
    user: req.user, products, categories,
    activeCat: cat,
    categoryOrder: getCategoryOrder(),
    gameCats: getGameCategories(),
    siteName: res.locals.siteName || 'Admin',
    error: req.query.error||null, success: req.query.success||null
  });
});

// ── PRODUCTS — product detail page (layer 3) ──
router.get('/products/:cat/:prodId', (req, res) => {
  const categories = getAllCategories();
  const { cat, prodId } = req.params;
  if (!categories.includes(cat)) return res.redirect('/admin/products/game');
  const prods = readProducts(cat);
  const product = prods.find(p => p.id === prodId);
  if (!product) return res.redirect('/admin/products/' + cat + '?error=' + encodeURIComponent('Produk tidak ditemukan'));
  res.render('admin/product-detail', {
    user: req.user, cat, product, categories,
    siteName: res.locals.siteName || 'Admin',
    error: req.query.error||null, success: req.query.success||null
  });
});

// ── category order ────────────────────────────
router.post('/products/category-order', express.json(), (req, res) => {
  try {
    const { order } = req.body;
    if (!Array.isArray(order)) return res.json({ status: false, message: 'order harus array' });
    saveCategoryOrder(order);
    res.json({ status: true });
  } catch (e) { res.json({ status: false, message: e.message }); }
});

// ── game sub-categories ───────────────────────
router.post('/products/game-categories/save', express.json(), (req, res) => {
  try {
    const { game, subcategories } = req.body;
    if (!game) return res.json({ status: false, message: 'game wajib diisi' });
    const gc = getGameCategories();
    gc[game] = { subcategories: subcategories || [] };
    saveGameCategories(gc);
    res.json({ status: true });
  } catch (e) { res.json({ status: false, message: e.message }); }
});

// ── PRODUCT CRUD ──────────────────────────────
router.post('/products/product/add', (req, res) => {
  const { category, nama, icon_url, banner_url, format_order, populer, checknicname_api, checknicname_path, deskripsi } = req.body;
  try {
    if (!category || !nama) return res.redirect('/admin/products/' + (category||'game') + '?error='+encodeURIComponent('Kategori dan nama produk wajib diisi'));
    addProduct(category, { nama, icon_url, banner_url, format_order, populer, checknicname_api, checknicname_path, deskripsi });
    res.redirect('/admin/products/' + category + '?success='+encodeURIComponent('Produk "'+nama+'" berhasil ditambahkan'));
  } catch (e) { res.redirect('/admin/products/' + (req.body.category||'game') + '?error='+encodeURIComponent(e.message)); }
});
router.post('/products/product/edit', express.json(), (req, res) => {
  const { category, productId, nama, icon_url, banner_url, format_order, populer, checknicname_api, checknicname_path, deskripsi } = req.body;
  try {
    editProduct(category, productId, { nama, icon_url, banner_url, format_order, populer, checknicname_api, checknicname_path, deskripsi });
    res.json({ status: true });
  } catch (e) { res.json({ status: false, message: e.message }); }
});
// ── PRODUCT EDIT — form POST from product-detail page ──
router.post('/products/product/edit-form', (req, res) => {
  const { category, productId, nama, icon_url, banner_url, format_order, populer, checknicname_api, checknicname_path, deskripsi } = req.body;
  try {
    if (!category || !productId) return res.redirect('/admin/products/game?error='+encodeURIComponent('Parameter tidak valid'));
    editProduct(category, productId, { nama, icon_url, banner_url, format_order, populer, checknicname_api, checknicname_path, deskripsi });
    res.redirect('/admin/products/' + category + '/' + productId + '?success='+encodeURIComponent('Produk berhasil diperbarui'));
  } catch (e) { res.redirect('/admin/products/' + (category||'game') + '/' + (productId||'') + '?error='+encodeURIComponent(e.message)); }
});
router.post('/products/product/delete', express.json(), (req, res) => {
  const { category, productId } = req.body;
  try { deleteProduct(category, productId); res.json({ status: true }); }
  catch (e) { res.json({ status: false, message: e.message }); }
});
router.post('/products/product/reorder', express.json(), (req, res) => {
  const { category, orderedIds } = req.body;
  try { reorderProducts(category, orderedIds); res.json({ status: true }); }
  catch (e) { res.json({ status: false, message: e.message }); }
});

// ── VARIANT CRUD ──────────────────────────────
router.post('/products/variant/add', express.json(), (req, res) => {
  const { category, productId, nama, icon_url } = req.body;
  try {
    if (!category || !productId || !nama) return res.json({ status: false, message: 'Kategori, produk, dan nama varian wajib diisi' });
    const varian = addVariant(category, productId, { nama, icon_url });
    res.json({ status: true, varian });
  } catch (e) { res.json({ status: false, message: e.message }); }
});
router.post('/products/variant/edit', express.json(), (req, res) => {
  const { category, productId, variantId, nama, icon_url } = req.body;
  try {
    editVariant(category, productId, variantId, { nama, icon_url });
    res.json({ status: true });
  } catch (e) { res.json({ status: false, message: e.message }); }
});
router.post('/products/variant/delete', express.json(), (req, res) => {
  const { category, productId, variantId } = req.body;
  try { deleteVariant(category, productId, variantId); res.json({ status: true }); }
  catch (e) { res.json({ status: false, message: e.message }); }
});
router.post('/products/variant/reorder', express.json(), (req, res) => {
  const { category, productId, orderedIds } = req.body;
  try { reorderVariants(category, productId, orderedIds); res.json({ status: true }); }
  catch (e) { res.json({ status: false, message: e.message }); }
});

// ── ITEM CRUD ─────────────────────────────────
router.post('/products/item/add', express.json(), (req, res) => {
  const { category, productId, variantId, kode, nama, icon_url, harga } = req.body;
  try {
    if (!category || !productId || !variantId || !kode || !nama)
      return res.json({ status: false, message: 'Kategori, produk, varian, kode, nama wajib diisi' });
    const item = addItem(category, productId, variantId, { kode, nama, icon_url: icon_url || '', harga: harga || 0 });
    res.json({ status: true, item });
  } catch (e) { res.json({ status: false, message: e.message }); }
});
router.post('/products/item/edit', express.json(), (req, res) => {
  const { category, productId, variantId, kode, nama, harga, status } = req.body;
  try {
    editItem(category, productId, variantId, kode, { nama, harga, status });
    res.json({ status: true });
  } catch (e) { res.json({ status: false, message: e.message }); }
});
router.post('/products/item/delete', express.json(), (req, res) => {
  const { category, productId, variantId, kode } = req.body;
  try { deleteItem(category, productId, variantId, kode); res.json({ status: true }); }
  catch (e) { res.json({ status: false, message: e.message }); }
});
router.post('/products/item/toggle', express.json(), (req, res) => {
  const { category, productId, variantId, kode } = req.body;
  try { const active = toggleItem(category, productId, variantId, kode); res.json({ status: true, active }); }
  catch (e) { res.json({ status: false, message: e.message }); }
});
router.post('/products/item/reorder', express.json(), (req, res) => {
  const { category, productId, variantId, orderedKodes } = req.body;
  try { reorderItems(category, productId, variantId, orderedKodes); res.json({ status: true }); }
  catch (e) { res.json({ status: false, message: e.message }); }
});

// ── Upload/Sync (legacy) ──────────────────────
router.post('/products/upload', (req, res) => {
  const { category } = req.body;
  if (!req.files?.product_file) return res.redirect('/admin/products?error=File+tidak+ditemukan');
  try {
    const parsed = JSON.parse(req.files.product_file.data.toString());
    saveProducts(category, Array.isArray(parsed) ? parsed : [parsed]);
    res.redirect('/admin/products?success='+encodeURIComponent('Upload berhasil'));
  } catch (e) { res.redirect('/admin/products?error='+encodeURIComponent(e.message)); }
});
router.post('/products/sync', async (req, res) => {
  try {
    const { category } = req.body;
    const priceList = await oke.getPriceList();
    if (!priceList?.length) return res.redirect('/admin/products?error=Gagal+ambil+data+OkeConnect');
    const catMap = {
      game: ['DIGITAL'], pulsa: ['PULSA'], data: ['KUOTA'],
      ewallet: ['DOMPET DIGITAL'], tagihan: ['TAGIHAN','TOKEN PLN','PASCABAYAR','FINANCE','AIR PDAM']
    };
    const target = category || 'all';
    let total = 0;
    const cats = target === 'all' ? Object.keys(catMap) : [target];
    for (const cat of cats) {
      const kws = catMap[cat] || [];
      const filtered = priceList.filter(p => kws.some(k => (p.kategori||'').toUpperCase().includes(k)));
      if (filtered.length) { saveProducts(cat, filtered); total += filtered.length; }
    }
    res.redirect('/admin/products?success='+encodeURIComponent(`Sync selesai (${total} produk)`));
  } catch (e) { res.redirect('/admin/products?error='+encodeURIComponent(e.message)); }
});
router.post('/products/update-image', express.json(), (req, res) => {
  const { category, productId, image_url } = req.body;
  try {
    if (productId) {
      const prods = readProducts(category);
      const pidx = prods.findIndex(p => p.id === productId);
      if (pidx !== -1) prods[pidx].icon_url = image_url;
      saveProducts(category, prods);
    }
    res.json({ status: true });
  } catch (e) { res.json({ status: false, message: e.message }); }
});

// ── PROMO CODES ───────────────────────────────
router.get('/promo', (req, res) => {
  res.render('admin/promo', {
    user: req.user, promos: readJson(PromoPath(), []),
    error: req.query.error||null, success: req.query.success||null
  });
});
router.post('/promo/add', (req, res) => {
  try {
    const promos = readJson(PromoPath(), []);
    const { code, type, value, min_order, max_uses, expires_at, applies_to } = req.body;
    if (!code||!type||!value) return res.redirect('/admin/promo?error=Kode%2C+tipe%2C+nilai+wajib');
    if (promos.find(p => p.code.toUpperCase() === code.toUpperCase().trim()))
      return res.redirect('/admin/promo?error='+encodeURIComponent('Kode sudah ada'));
    promos.push({
      id: nanoid(), code: code.toUpperCase().trim(), type,
      value: parseFloat(value)||0, min_order: parseInt(min_order)||0,
      max_uses: parseInt(max_uses)||0, used_count: 0,
      expires_at: expires_at ? new Date(expires_at).toISOString() : null,
      applies_to: applies_to||'all', active: true, created_at: new Date().toISOString()
    });
    writeJson(PromoPath(), promos);
    res.redirect('/admin/promo?success=Kode+promo+ditambahkan');
  } catch (e) { res.redirect('/admin/promo?error='+encodeURIComponent(e.message)); }
});
router.post('/promo/edit', express.json(), (req, res) => {
  try {
    const promos = readJson(PromoPath(), []);
    const { id, code, type, value, min_order, max_uses, expires_at, applies_to } = req.body;
    const idx = promos.findIndex(p => p.id === id);
    if (idx === -1) return res.json({ status: false, message: 'Promo tidak ditemukan' });
    promos[idx] = { ...promos[idx], code: code.toUpperCase().trim(), type, value: parseFloat(value)||0, min_order: parseInt(min_order)||0, max_uses: parseInt(max_uses)||0, expires_at: expires_at ? new Date(expires_at).toISOString() : null, applies_to: applies_to||'all' };
    writeJson(PromoPath(), promos);
    res.json({ status: true });
  } catch (e) { res.json({ status: false, message: e.message }); }
});
router.post('/promo/toggle', express.json(), (req, res) => {
  try {
    const promos = readJson(PromoPath(), []);
    const idx = promos.findIndex(p => p.id === req.body.id);
    if (idx === -1) return res.json({ status: false, message: 'Promo tidak ditemukan' });
    promos[idx].active = !promos[idx].active;
    writeJson(PromoPath(), promos);
    res.json({ status: true, active: promos[idx].active });
  } catch (e) { res.json({ status: false, message: e.message }); }
});
router.post('/promo/delete', express.json(), (req, res) => {
  try {
    writeJson(PromoPath(), readJson(PromoPath(),[]).filter(p => p.id !== req.body.id));
    res.json({ status: true });
  } catch (e) { res.json({ status: false, message: e.message }); }
});

// ── BANNERS ───────────────────────────────────
router.get('/banners', (req, res) => res.render('admin/banners', { user: req.user, banners: readJson(BannersPath(),[]), config: getConfig(), siteName: res.locals.siteName, error: req.query.error||null, success: req.query.success||null }));
router.post('/banners/settings', (req, res) => {
  try {
    const _p = require('path').join(__dirname,'../data/config.json');
    const raw = JSON.parse(require('fs').readFileSync(_p,'utf-8'));
    if (!raw.display) raw.display = {};
    raw.display.banner_width_pct = parseFloat(req.body.banner_width_pct) || 100;
    raw.display.banner_height_px = parseInt(req.body.banner_height_px)   || 145;
    raw.display.banner_zoom      = parseFloat(req.body.banner_zoom)      || 1.0;
    saveConfig(raw);
    res.redirect('/admin/banners?success=Pengaturan+banner+disimpan');
  } catch(e){ res.redirect('/admin/banners?error='+encodeURIComponent(e.message)); }
});
router.post('/banners/add', (req, res) => {
  try {
    const bs = readJson(BannersPath(), []);
    const { title, image_url, subtitle, link, color_from, color_to, order } = req.body;
    bs.push({ id: nanoid(), title, image_url: image_url||'', subtitle: subtitle||'', link: link||'/', color_from: color_from||'#0d2b6b', color_to: color_to||'#1d4ed8', order: parseInt(order)||bs.length+1, active: true });
    bs.sort((a,b)=>(a.order||0)-(b.order||0));
    writeJson(BannersPath(), bs);
    res.redirect('/admin/banners?success=Banner+ditambahkan');
  } catch (e) { res.redirect('/admin/banners?error='+encodeURIComponent(e.message)); }
});
router.post('/banners/update', (req, res) => {
  try {
    const bs = readJson(BannersPath(), []); const { id, title, image_url, subtitle, link, color_from, color_to } = req.body;
    const i = bs.findIndex(b=>b.id===id); if (i!==-1) bs[i]={...bs[i],title,image_url:image_url||'',subtitle:subtitle||'',link:link||'/',color_from:color_from||'#0d2b6b',color_to:color_to||'#1d4ed8'};
    writeJson(BannersPath(),bs); res.redirect('/admin/banners?success=Banner+diperbarui');
  } catch (e) { res.redirect('/admin/banners?error='+encodeURIComponent(e.message)); }
});
router.post('/banners/toggle', (req,res)=>{ try { const bs=readJson(BannersPath(),[]); const i=bs.findIndex(b=>b.id===req.body.id); if(i!==-1)bs[i].active=!bs[i].active; writeJson(BannersPath(),bs); res.redirect('/admin/banners?success=Status+banner+diubah'); } catch(e){res.redirect('/admin/banners?error='+encodeURIComponent(e.message));} });
router.post('/banners/delete', (req,res)=>{ try { writeJson(BannersPath(),readJson(BannersPath(),[]).filter(b=>b.id!==req.body.id)); res.redirect('/admin/banners?success=Banner+dihapus'); } catch(e){res.redirect('/admin/banners?error='+encodeURIComponent(e.message));} });

// ── FLASHSALE ─────────────────────────────────
router.get('/flashsale', (req,res)=>res.render('admin/flashsale',{user:req.user,flashsale:readJson(FlashPath(),[]),config:getConfig(),siteName:res.locals.siteName,error:req.query.error||null,success:req.query.success||null}));
router.post('/flashsale/settings', (req,res)=>{
  try {
    const _p = require('path').join(__dirname,'../data/config.json');
    const raw = JSON.parse(require('fs').readFileSync(_p,'utf-8'));
    if (!raw.display) raw.display = {};
    raw.display.fs_card_width  = parseInt(req.body.fs_card_width)   || 150;
    raw.display.fs_card_height = parseInt(req.body.fs_card_height)  || 110;
    raw.display.fs_zoom        = parseFloat(req.body.fs_zoom)       || 1.0;
    saveConfig(raw);
    res.redirect('/admin/flashsale?success=Pengaturan+flash+sale+disimpan');
  } catch(e){ res.redirect('/admin/flashsale?error='+encodeURIComponent(e.message)); }
});
router.post('/flashsale/add', (req,res)=>{ try { const fs2=readJson(FlashPath(),[]); const{kode,nama,category,harga_normal,harga_flash,image_url,ends_at}=req.body; fs2.push({id:nanoid(),kode,nama,category:category||'game',harga_normal:parseInt(harga_normal)||0,harga_flash:parseInt(harga_flash)||0,image_url:image_url||'',ends_at:ends_at?new Date(ends_at).toISOString():new Date(Date.now()+24*3600000).toISOString(),maksimal_dibeli:parseInt(req.body.maksimal_dibeli)||0,total_dibeli:0,active:true,created_at:new Date().toISOString()}); writeJson(FlashPath(),fs2); res.redirect('/admin/flashsale?success=Flash+sale+ditambahkan'); } catch(e){res.redirect('/admin/flashsale?error='+encodeURIComponent(e.message));} });
router.post('/flashsale/toggle', (req,res)=>{ try { const fs2=readJson(FlashPath(),[]); const i=fs2.findIndex(f=>f.id===req.body.id); if(i!==-1)fs2[i].active=!fs2[i].active; writeJson(FlashPath(),fs2); res.redirect('/admin/flashsale?success=Status+diubah'); } catch(e){res.redirect('/admin/flashsale?error='+encodeURIComponent(e.message));} });
router.post('/flashsale/delete', (req,res)=>{ try { writeJson(FlashPath(),readJson(FlashPath(),[]).filter(f=>f.id!==req.body.id)); res.redirect('/admin/flashsale?success=Item+dihapus'); } catch(e){res.redirect('/admin/flashsale?error='+encodeURIComponent(e.message));} });
router.post('/flashsale/edit', (req,res)=>{ try { const fs2=readJson(FlashPath(),[]); const{id,kode,nama,category,harga_normal,harga_flash,image_url,ends_at}=req.body; const i=fs2.findIndex(f=>f.id===id); if(i!==-1){fs2[i]={...fs2[i],kode:kode||fs2[i].kode,nama:nama||fs2[i].nama,category:category||fs2[i].category,harga_normal:parseInt(harga_normal)||fs2[i].harga_normal,harga_flash:parseInt(harga_flash)||fs2[i].harga_flash,image_url:image_url!==undefined?image_url:fs2[i].image_url,ends_at:ends_at?new Date(ends_at).toISOString():fs2[i].ends_at,maksimal_dibeli:req.body.maksimal_dibeli!==undefined?parseInt(req.body.maksimal_dibeli)||0:(fs2[i].maksimal_dibeli||0)};} writeJson(FlashPath(),fs2); res.redirect('/admin/flashsale?success=Flash+sale+diperbarui'); } catch(e){res.redirect('/admin/flashsale?error='+encodeURIComponent(e.message));} });

// ── POPUPS ────────────────────────────────────
router.get('/popups', (req, res) => {
  try {
    res.render('admin/popups', {
      user: req.user,
      popups: readJson(PopupsPath(), []),
      error: req.query.error || null,
      success: req.query.success || null,
      siteName: res.locals.siteName,
      currentPath: '/admin/popups'
    });
  } catch (e) { res.redirect('/admin?error=' + encodeURIComponent(e.message)); }
});
router.post('/popups/add', (req,res)=>{ try { const list=readJson(PopupsPath(),[]); const{description,image_url,link,link_text}=req.body; if(!description||!description.trim()) return res.redirect('/admin/popups?error='+encodeURIComponent('Deskripsi wajib diisi')); list.push({id:nanoid(),description:description.trim(),image_url:(image_url||'').trim(),link:(link||'').trim(),link_text:(link_text||'').trim(),active:true,created_at:new Date().toISOString()}); writeJson(PopupsPath(),list); res.redirect('/admin/popups?success=Popup+berhasil+ditambahkan'); } catch(e){res.redirect('/admin/popups?error='+encodeURIComponent(e.message));} });
router.post('/popups/edit', (req,res)=>{ try { const list=readJson(PopupsPath(),[]); const{id,description,image_url,link,link_text}=req.body; const i=list.findIndex(p=>p.id===id); if(i!==-1){list[i]={...list[i],description:(description||'').trim()||list[i].description,image_url:(image_url||'').trim(),link:(link||'').trim(),link_text:(link_text||'').trim()};} writeJson(PopupsPath(),list); res.redirect('/admin/popups?success=Popup+berhasil+diperbarui'); } catch(e){res.redirect('/admin/popups?error='+encodeURIComponent(e.message));} });
router.post('/popups/toggle', (req,res)=>{ try { const list=readJson(PopupsPath(),[]); const i=list.findIndex(p=>p.id===req.body.id); if(i!==-1)list[i].active=!list[i].active; writeJson(PopupsPath(),list); res.redirect('/admin/popups?success=Status+popup+diubah'); } catch(e){res.redirect('/admin/popups?error='+encodeURIComponent(e.message));} });
router.post('/popups/delete', (req,res)=>{ try { writeJson(PopupsPath(),readJson(PopupsPath(),[]).filter(p=>p.id!==req.body.id)); res.redirect('/admin/popups?success=Popup+dihapus'); } catch(e){res.redirect('/admin/popups?error='+encodeURIComponent(e.message));} });

// ── CONFIG ────────────────────────────────────
router.get('/config', (req,res)=>res.render('admin/config',{user:req.user,config:getConfig(),error:req.query.error||null,success:req.query.success||null,siteName:res.locals.siteName}));
router.post('/config', (req,res)=>{ try { const def=getDefaultConfig(); const cfg=getConfig(); if(!cfg.profit)cfg.profit=def.profit; if(!cfg.reseller)cfg.reseller=def.reseller; if(!cfg.reseller.profit)cfg.reseller.profit=def.reseller.profit; if(!cfg.deposit)cfg.deposit=def.deposit; ['game','pulsa','data','ewallet','tagihan','digital','streaming'].forEach(cat=>{ const rt=req.body[`profit_${cat}_type`]; if(rt)cfg.profit[cat]={type:rt,value:parseFloat(req.body[`profit_${cat}_value`])||0}; const rs=req.body[`reseller_${cat}_type`]; if(rs)cfg.reseller.profit[cat]={type:rs,value:parseFloat(req.body[`reseller_${cat}_value`])||0}; }); if(req.body.reseller_join_price)cfg.reseller.join_price=parseFloat(req.body.reseller_join_price)||50000; if(req.body.deposit_min)cfg.deposit.min=parseInt(req.body.deposit_min)||10000; saveConfig(cfg); res.redirect('/admin/config?success=Config+disimpan'); } catch(e){res.redirect('/admin/config?error='+encodeURIComponent(e.message));} });

// ── BRANDING ──────────────────────────────────
router.post('/config/branding', (req, res) => {
  try {
    const cfg = getConfig();
    if (!cfg.branding) cfg.branding = {};
    cfg.branding.site_name = (req.body.site_name || '').trim();
    cfg.branding.logo_url  = (req.body.logo_url  || '').trim();
    cfg.branding.icon_url  = (req.body.icon_url  || '').trim();
    saveConfig(cfg);
    res.redirect('/admin/config?success=Branding+berhasil+disimpan');
  } catch (e) { res.redirect('/admin/config?error=' + encodeURIComponent(e.message)); }
});

// ── CS BUTTON ─────────────────────────────────
router.post('/config/cs', (req, res) => {
  try {
    const cfg = getConfig();
    if (!cfg.cs) cfg.cs = {};
    cfg.cs.cs_icon = (req.body.cs_icon || '').trim();
    cfg.cs.cs_link = (req.body.cs_link || '').trim();
    saveConfig(cfg);
    res.redirect('/admin/config?success=CS+button+berhasil+disimpan');
  } catch (e) { res.redirect('/admin/config?error=' + encodeURIComponent(e.message)); }
});

// ── INTEGRATIONS (Google + Resend) ────────────
router.post('/config/integrations', (req, res) => {
  try {
    const cfg = getConfig();
    if (!cfg.integrations) cfg.integrations = {};
    cfg.integrations.google_client_id     = (req.body.google_client_id     || '').trim();
    cfg.integrations.google_client_secret = (req.body.google_client_secret || '').trim();
    cfg.integrations.resend_api_key       = (req.body.resend_api_key       || '').trim();
    cfg.integrations.email_from           = (req.body.email_from           || '').trim();

    // Apply to process.env saat ini juga (untuk Resend yang tidak perlu restart)
    if (cfg.integrations.resend_api_key && !process.env.RESEND_API_KEY) {
      process.env.RESEND_API_KEY = cfg.integrations.resend_api_key;
    }
    if (cfg.integrations.email_from && !process.env.EMAIL_FROM) {
      process.env.EMAIL_FROM = cfg.integrations.email_from;
    }
    // Google membutuhkan restart agar Passport strategy dimuat ulang
    const googleChanged = cfg.integrations.google_client_id || cfg.integrations.google_client_secret;

    saveConfig(cfg);
    const msg = googleChanged
      ? 'Integrasi disimpan. Restart server agar Google Auth aktif.'
      : 'Integrasi berhasil disimpan.';
    res.redirect('/admin/config?success=' + encodeURIComponent(msg));
  } catch (e) { res.redirect('/admin/config?error=' + encodeURIComponent(e.message)); }
});

// ── TEST EMAIL ────────────────────────────────
router.post('/config/test-email', express.json(), async (req, res) => {
  try {
    const adminUser = await db.findUser({ username: req.user.username });
    if (!adminUser || !adminUser.email) return res.json({ status: false, message: 'Admin tidak memiliki email terdaftar' });
    const { sendEmail } = require('../lib/email');
    const result = await sendEmail({
      to: adminUser.email,
      subject: 'Test Email dari Admin Dashboard',
      html: `<p>Email test berhasil dikirim dari admin dashboard <strong>${process.env.SITE_NAME || 'H2H TopUp'}</strong>.</p><p>Waktu: ${new Date().toLocaleString('id-ID')}</p>`
    });
    if (result.ok) {
      res.json({ status: true, to: adminUser.email });
    } else {
      res.json({ status: false, message: result.reason || 'Gagal mengirim email. Pastikan Resend API Key sudah diisi.' });
    }
  } catch (e) { res.json({ status: false, message: e.message }); }
});

// ── BOT TELEGRAM MANAGEMENT ───────────────────
const botManager = require('../lib/bot-manager');
const botDb      = require('../lib/bot-db');

function getBotStats(bot) {
  try {
    const users = botDb.getUsers(bot.owner_username);
    const txs   = botDb.getTransactions(bot.owner_username);
    const wallet = botDb.getWallet(bot.owner_username);
    return { users: users.length, transactions: txs.length, wallet: wallet.balance || 0 };
  } catch { return { users: 0, transactions: 0, wallet: 0 }; }
}

router.get('/bots', async (req, res) => {
  try {
    const bots    = botManager.readBots();
    const running = botManager.getStatus();
    const stats   = {};
    for (const b of bots) stats[b.id] = getBotStats(b);
    res.render('admin/bots', {
      user: req.user, bots, running, botStats: stats,
      isExpiredFn: botManager.isExpired,
      success: req.query.success || null,
      error:   req.query.error   || null
    });
  } catch (e) {
    res.render('admin/bots', { user: req.user, bots: [], running: [], botStats: {}, isExpiredFn: () => false, success: null, error: e.message });
  }
});

router.get('/bots/add', async (req, res) => {
  const { users } = await db.getUsers().catch(() => ({ users: [] }));
  res.render('admin/bot-form', { user: req.user, bot: null, users: users || [], error: req.query.error || null });
});

router.post('/bots/add', async (req, res) => {
  try {
    const { name, token, owner_id, owner_username, owner_name, api_key, thumb, expired_at, active } = req.body;
    if (!name || !token || !owner_id || !owner_username || !owner_name || !api_key) {
      const { users } = await db.getUsers().catch(() => ({ users: [] }));
      return res.render('admin/bot-form', { user: req.user, bot: null, users: users || [], error: 'Semua field wajib diisi.' });
    }
    // Validate API key belongs to registered user
    const siteUser = await db.findUser({ apikey: api_key }).catch(() => null);
    if (!siteUser) {
      const { users } = await db.getUsers().catch(() => ({ users: [] }));
      return res.render('admin/bot-form', { user: req.user, bot: null, users: users || [], error: 'API Key tidak valid. Pastikan pilih dari user terdaftar di website.' });
    }
    const bots = botManager.readBots();
    if (bots.find(b => b.token === token)) {
      const { users } = await db.getUsers().catch(() => ({ users: [] }));
      return res.render('admin/bot-form', { user: req.user, bot: null, users: users || [], error: 'Token sudah digunakan oleh bot lain.' });
    }
    const { v4: uuidv4 } = require('uuid');
    const newBot = {
      id: uuidv4(), name, token, owner_id, owner_username, owner_name, api_key,
      thumb: thumb || '',
      expired_at: expired_at || null,
      active: active === '1',
      created_at: new Date().toISOString()
    };
    bots.push(newBot);
    botManager.writeBots(bots);
    if (newBot.active) botManager.startBot(newBot);
    res.redirect('/admin/bots?success=' + encodeURIComponent(`Bot "${name}" berhasil ditambahkan`));
  } catch (e) {
    res.redirect('/admin/bots?error=' + encodeURIComponent(e.message));
  }
});

router.get('/bots/:id/edit', async (req, res) => {
  const bots = botManager.readBots();
  const bot  = bots.find(b => b.id === req.params.id);
  if (!bot) return res.redirect('/admin/bots?error=Bot+tidak+ditemukan');
  const { users } = await db.getUsers().catch(() => ({ users: [] }));
  res.render('admin/bot-form', { user: req.user, bot, users: users || [], error: req.query.error || null });
});

router.post('/bots/:id/edit', async (req, res) => {
  try {
    const bots = botManager.readBots();
    const i    = bots.findIndex(b => b.id === req.params.id);
    if (i < 0) return res.redirect('/admin/bots?error=Bot+tidak+ditemukan');
    const { name, token, owner_id, owner_name, api_key, thumb, expired_at, active } = req.body;
    // Validate API key
    const siteUser = await db.findUser({ apikey: api_key }).catch(() => null);
    if (!siteUser) return res.redirect(`/admin/bots/${req.params.id}/edit?error=` + encodeURIComponent('API Key tidak valid.'));
    const wasActive = bots[i].active;
    bots[i] = {
      ...bots[i], name, token, owner_id, owner_name, api_key,
      thumb: thumb || '',
      expired_at: expired_at || null,
      active: active === '1',
      updated_at: new Date().toISOString()
    };
    botManager.writeBots(bots);
    // Restart bot if token or active state changed
    if (wasActive) botManager.stopBot(req.params.id);
    if (bots[i].active) botManager.startBot(bots[i]);
    res.redirect('/admin/bots?success=' + encodeURIComponent(`Bot "${name}" diperbarui`));
  } catch (e) {
    res.redirect('/admin/bots?error=' + encodeURIComponent(e.message));
  }
});

router.post('/bots/:id/toggle', (req, res) => {
  try {
    const bots = botManager.readBots();
    const i    = bots.findIndex(b => b.id === req.params.id);
    if (i < 0) return res.redirect('/admin/bots?error=Bot+tidak+ditemukan');
    bots[i].active = !bots[i].active;
    botManager.writeBots(bots);
    if (bots[i].active) botManager.startBot(bots[i]);
    else botManager.stopBot(req.params.id);
    res.redirect('/admin/bots?success=' + encodeURIComponent(`Bot "${bots[i].name}" ${bots[i].active ? 'diaktifkan' : 'dinonaktifkan'}`));
  } catch (e) { res.redirect('/admin/bots?error=' + encodeURIComponent(e.message)); }
});

router.post('/bots/:id/restart', (req, res) => {
  try {
    botManager.restartBot(req.params.id);
    res.redirect('/admin/bots?success=Bot+direstart');
  } catch (e) { res.redirect('/admin/bots?error=' + encodeURIComponent(e.message)); }
});

router.post('/bots/:id/delete', (req, res) => {
  try {
    const bots = botManager.readBots();
    const bot  = bots.find(b => b.id === req.params.id);
    if (!bot) return res.redirect('/admin/bots?error=Bot+tidak+ditemukan');
    botManager.stopBot(req.params.id);
    // Remove data folder
    const botDir = botDb.getBotDir(bot.owner_username);
    if (fs.existsSync(botDir)) fs.rmSync(botDir, { recursive: true });
    botManager.writeBots(bots.filter(b => b.id !== req.params.id));
    res.redirect('/admin/bots?success=' + encodeURIComponent(`Bot "${bot.name}" dihapus`));
  } catch (e) { res.redirect('/admin/bots?error=' + encodeURIComponent(e.message)); }
});

// ── TRANSACTIONS ──────────────────────────────
// ── ANON ORDERS ────────────────────────────────
router.get('/anon-orders', (req, res) => {
  try {
    const anonPath = path.join(__dirname, '../data/anon_orders.json');
    const orders = fs.existsSync(anonPath) ? JSON.parse(fs.readFileSync(anonPath, 'utf8')) : [];
    const { status, category } = req.query;
    let filtered = orders;
    if (status)   filtered = filtered.filter(o => o.status === status);
    if (category) filtered = filtered.filter(o => o.category === category);
    res.render('admin/anon-orders', {
      user: req.user,
      orders: filtered.slice(0, 300),
      total: orders.length,
      filter: { status, category },
      categories: getAllCategories(),
      error: null
    });
  } catch (e) {
    res.render('admin/anon-orders', { user: req.user, orders: [], total: 0, filter: {}, categories: getAllCategories(), error: e.message });
  }
});

router.get('/transactions', async (req,res)=>{ try { const{transactions}=await db.getTransactions(); const{category,status,username}=req.query; let f=transactions; if(category)f=f.filter(t=>t.category===category); if(status)f=f.filter(t=>t.status===status); if(username)f=f.filter(t=>t.username===username); res.render('admin/transactions',{user:req.user,transactions:f.slice(0,200),categories:getAllCategories(),filter:{category,status,username},error:null}); } catch(e){res.render('admin/transactions',{user:req.user,transactions:[],categories:getAllCategories(),filter:{},error:e.message});} });

// ── KONFIRMASI MANUAL PAYMENT → PROSES OTOMATIS ──
router.post('/transactions/confirm-manual', express.json(), async (req, res) => {
  const { trx_id } = req.body;
  if (!trx_id) return res.json({ status: false, message: 'trx_id diperlukan' });
  try {
    const { transactions } = await db.getTransactions();
    const trx = transactions.find(t => t.id === trx_id);
    if (!trx) return res.json({ status: false, message: 'Transaksi tidak ditemukan' });
    if (trx.status !== 'pending_payment') return res.json({ status: false, message: 'Status bukan pending_payment: ' + trx.status });

    const product = findProduct(trx.product_code);
    if (!product) return res.json({ status: false, message: 'Produk tidak ditemukan: ' + trx.product_code });

    const refID = 'TRX' + Date.now().toString().slice(-8);
    let okeStatus = 'process', okeMsg = '';
    try {
      const okeResp = await oke.order(trx.product_code, trx.dest || trx.target, refID);
      okeStatus = okeResp.status || 'process';
      okeMsg    = okeResp.message || '';
    } catch (e) { okeStatus = 'failed'; okeMsg = e.message; }

    await db.updateTransaction(trx_id, {
      status: okeStatus,
      ref_id: refID,
      provider_message: okeMsg,
      executed_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });

    res.json({ status: true, result: okeStatus, message: okeMsg || 'Order ' + okeStatus });
  } catch (e) { res.json({ status: false, message: e.message }); }
});

// ── DEPOSITS ──────────────────────────────────
router.get('/deposits', async (req,res)=>{ try { const{deposits}=await db.getDeposits(); res.render('admin/deposits',{user:req.user,deposits:deposits.slice(0,200),error:null,success:req.query.success||null}); } catch(e){res.render('admin/deposits',{user:req.user,deposits:[],error:e.message,success:null});} });
router.post('/deposits/approve', async (req,res)=>{ const{trxid}=req.body; try { const{deposits}=await db.getDeposits(); const dep=deposits.find(d=>d.trxid===trxid); if(!dep)return res.redirect('/admin/deposits?error=Deposit+tidak+ditemukan'); await db.updateDeposit(trxid,{status:'success',paid_at:new Date().toISOString(),approved_by:'admin'}); const u=await db.findUser({id:dep.user_id}); if(u)await db.updateUser(u.id,{balance:(u.balance||0)+dep.amount}); res.redirect('/admin/deposits?success=Deposit+disetujui'); } catch(e){res.redirect('/admin/deposits?error='+encodeURIComponent(e.message));} });

// ── INFORMASI ─────────────────────────────────
function getInformasiPath() { return path.join(__dirname, '../data/informasi.json'); }

router.get('/informasi', (req, res) => {
  try {
    const list = readJson(getInformasiPath(), []);
    res.render('admin/informasi', {
      user: req.user, informasi: list,
      error: req.query.error || null, success: req.query.success || null,
      siteName: res.locals.siteName,
      currentPath: '/admin/informasi'
    });
  } catch (e) { res.redirect('/admin?error=' + encodeURIComponent(e.message)); }
});

router.post('/informasi/add', (req, res) => {
  try {
    const list = readJson(getInformasiPath(), []);
    const { judul, kategori, icon, ringkasan, gambar, konten } = req.body;
    if (!judul || !judul.trim()) return res.redirect('/admin/informasi?error=' + encodeURIComponent('Judul wajib diisi'));
    if (!konten || !konten.trim()) return res.redirect('/admin/informasi?error=' + encodeURIComponent('Konten wajib diisi'));
    list.unshift({
      id: nanoid(),
      judul: judul.trim(),
      kategori: (kategori || '').trim(),
      icon: (icon || '').trim(),
      ringkasan: (ringkasan || '').trim(),
      gambar: (gambar || '').trim(),
      konten: konten.trim(),
      active: true,
      created_at: new Date().toISOString()
    });
    writeJson(getInformasiPath(), list);
    res.redirect('/admin/informasi?success=Informasi+berhasil+ditambahkan');
  } catch (e) { res.redirect('/admin/informasi?error=' + encodeURIComponent(e.message)); }
});

router.post('/informasi/edit', (req, res) => {
  try {
    const list = readJson(getInformasiPath(), []);
    const { id, judul, kategori, icon, ringkasan, gambar, konten } = req.body;
    const i = list.findIndex(x => x.id === id);
    if (i !== -1) {
      list[i] = {
        ...list[i],
        judul: (judul || '').trim() || list[i].judul,
        kategori: (kategori || '').trim(),
        icon: (icon || '').trim(),
        ringkasan: (ringkasan || '').trim(),
        gambar: (gambar || '').trim(),
        konten: (konten || '').trim() || list[i].konten,
        updated_at: new Date().toISOString()
      };
    }
    writeJson(getInformasiPath(), list);
    res.redirect('/admin/informasi?success=Informasi+berhasil+diperbarui');
  } catch (e) { res.redirect('/admin/informasi?error=' + encodeURIComponent(e.message)); }
});

router.post('/informasi/toggle', (req, res) => {
  try {
    const list = readJson(getInformasiPath(), []);
    const i = list.findIndex(x => x.id === req.body.id);
    if (i !== -1) list[i].active = !list[i].active;
    writeJson(getInformasiPath(), list);
    res.redirect('/admin/informasi?success=Status+informasi+diubah');
  } catch (e) { res.redirect('/admin/informasi?error=' + encodeURIComponent(e.message)); }
});

router.post('/informasi/delete', (req, res) => {
  try {
    writeJson(getInformasiPath(), readJson(getInformasiPath(), []).filter(x => x.id !== req.body.id));
    res.redirect('/admin/informasi?success=Informasi+dihapus');
  } catch (e) { res.redirect('/admin/informasi?error=' + encodeURIComponent(e.message)); }
});

// ── PAYMENT METHODS ───────────────────────────
router.get('/payment-methods', (req, res) => {
  const cfg = getConfig();
  let paymentMethods = cfg.payment_methods || [];
  // Auto-inject QRIS default jika belum ada
  if (!paymentMethods.find(m => m.type === 'qris')) {
    paymentMethods = [{ id: 'qris-default', type: 'qris', nama: 'QRIS', fee_pct: 0, enabled: true }, ...paymentMethods];
    cfg.payment_methods = paymentMethods;
    saveConfig(cfg);
  }
  res.render('admin/payment-methods', {
    user: req.user, config: cfg,
    paymentMethods,
    siteName: process.env.SITE_NAME || 'TopStore',
    currentPath: '/admin/payment-methods',
    error: req.query.error || null, success: req.query.success || null
  });
});
router.post('/payment-methods/save', express.json(), (req, res) => {
  try {
    const { methods } = req.body;
    if (!Array.isArray(methods)) return res.json({ status: false, message: 'Format tidak valid' });
    const cfg = getConfig();
    cfg.payment_methods = methods;
    saveConfig(cfg);
    res.json({ status: true });
  } catch (e) { res.json({ status: false, message: e.message }); }
});

// ── ADMIN BOT CONFIG ───────────────────────────
router.get('/adminbot', (req, res) => {
  const cfg = getConfig();
  res.render('admin/adminbot', {
    user: req.user, config: cfg,
    adminBot: cfg.admin_bot || { token: '', chat_id: '', enabled: false },
    siteName: process.env.SITE_NAME || 'TopStore',
    currentPath: '/admin/adminbot',
    error: req.query.error || null, success: req.query.success || null
  });
});
router.post('/adminbot/save', (req, res) => {
  try {
    const { token, chat_id, enabled } = req.body;
    const cfg = getConfig();
    cfg.admin_bot = {
      token: (token || '').trim(),
      chat_id: (chat_id || '').trim(),
      enabled: enabled === 'on' || enabled === 'true' || enabled === '1'
    };
    saveConfig(cfg);
    res.redirect('/admin/adminbot?success=' + encodeURIComponent('Konfigurasi bot admin tersimpan'));
  } catch (e) { res.redirect('/admin/adminbot?error=' + encodeURIComponent(e.message)); }
});
router.post('/adminbot/test', express.json(), async (req, res) => {
  try {
    const { token, chat_id } = req.body;
    if (!token || !chat_id) return res.json({ status: false, message: 'Token dan Chat ID wajib diisi' });
    const tgRes = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id, text: '✅ Test dari Admin Bot H2H TopUp — konfigurasi berhasil!' })
    });
    const tgData = await tgRes.json();
    if (tgData.ok) res.json({ status: true, message: 'Pesan terkirim ke Telegram!' });
    else res.json({ status: false, message: tgData.description || 'Gagal kirim pesan' });
  } catch (e) { res.json({ status: false, message: e.message }); }
});

// ── ANNOUNCEMENTS ─────────────────────────────
const { getAnnouncements, createAnnouncement, toggleAnnouncement: toggleAnn, deleteAnnouncement } = require('../lib/announcements');
router.get('/announcements', (req,res) => {
  const anns = getAnnouncements(false);
  res.render('admin/announcements', {
    user: req.user, announcements: anns,
    error: req.query.error || null, success: req.query.success || null,
    siteName: process.env.SITE_NAME || 'TopStore',
    currentPath: req.path.startsWith('/') ? '/admin/announcements' : req.path
  });
});
router.post('/announcements/create', (req,res) => {
  try {
    const { title, content, type } = req.body;
    if (!title || !content) return res.json({ status: false, message: 'Judul dan isi wajib diisi' });
    createAnnouncement({ title, content, type: type || 'info' });
    res.json({ status: true });
  } catch (e) { res.json({ status: false, message: e.message }); }
});
router.post('/announcements/toggle', (req,res) => {
  try {
    const { id, active } = req.body;
    toggleAnn(id, active === true || active === 'true');
    res.json({ status: true });
  } catch (e) { res.json({ status: false, message: e.message }); }
});
router.post('/announcements/delete', (req,res) => {
  try {
    deleteAnnouncement(req.body.id);
    res.json({ status: true });
  } catch (e) { res.json({ status: false, message: e.message }); }
});

module.exports = router;
