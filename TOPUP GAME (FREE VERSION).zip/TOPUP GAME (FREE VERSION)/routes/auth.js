const express  = require('express');
const router   = express.Router();
const bcrypt   = require('bcryptjs');
const passport = require('passport');
const db       = require('../lib/github-db');
const { createUser, generateApiKey, generateToken, generateOTP, hashPassword, checkPassword } = require('../lib/auth');
const { sendVerificationEmail, sendPasswordResetEmail, send2FAEmail } = require('../lib/email');

// ── LOGIN ─────────────────────────────────────
router.get('/login', (req, res) => {
  if (req.session?.user) return res.redirect('/dashboard');
  res.render('login', {
    error: req.query.error ? decodeURIComponent(req.query.error) : null,
    success: req.query.success ? decodeURIComponent(req.query.success) : null
  });
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await db.findUser({ username });
    if (!user) return res.render('login', { error: 'Username atau password salah', success: null });
    if (!user.password) return res.render('login', { error: 'Akun ini terdaftar via Google. Gunakan Login dengan Google.', success: null });
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.render('login', { error: 'Username atau password salah', success: null });
    if (!user.email_verified && user.role !== 'admin') {
      return res.render('login', {
        error: 'Email belum diverifikasi. Cek inbox (dan folder spam) kamu.',
        success: null
      });
    }
    // 2FA
    if (user.twofa_enabled) {
      const otp = generateOTP();
      await db.updateUser(user.id, {
        twofa_otp: otp,
        twofa_otp_expires: new Date(Date.now() + 10 * 60 * 1000).toISOString()
      });
      await send2FAEmail(user.email, otp, user.username);
      req.session.pending_2fa_user_id = user.id;
      return res.redirect('/2fa');
    }
    const { password: _, ...safeUser } = user;
    req.session.user = safeUser;
    if (user.role === 'admin') return res.redirect('/admin');
    res.redirect('/dashboard');
  } catch (e) {
    res.render('login', { error: 'Terjadi kesalahan: ' + e.message, success: null });
  }
});

// ── 2FA ──────────────────────────────────────
router.get('/2fa', (req, res) => {
  if (!req.session?.pending_2fa_user_id) return res.redirect('/login');
  res.render('2fa', { error: req.query.error ? decodeURIComponent(req.query.error) : null });
});

router.post('/2fa', async (req, res) => {
  const { otp } = req.body;
  const userId  = req.session?.pending_2fa_user_id;
  if (!userId) return res.redirect('/login');
  try {
    const user = await db.findUser({ id: userId });
    if (!user) return res.redirect('/login');
    if (!user.twofa_otp || user.twofa_otp !== otp.trim()) {
      return res.redirect('/2fa?error=' + encodeURIComponent('Kode OTP salah'));
    }
    if (new Date(user.twofa_otp_expires) < new Date()) {
      return res.redirect('/2fa?error=' + encodeURIComponent('Kode OTP sudah kadaluarsa'));
    }
    await db.updateUser(user.id, { twofa_otp: null, twofa_otp_expires: null });
    delete req.session.pending_2fa_user_id;
    const { password: _, ...safeUser } = user;
    req.session.user = safeUser;
    if (user.role === 'admin') return res.redirect('/admin');
    res.redirect('/dashboard');
  } catch (e) {
    res.redirect('/2fa?error=' + encodeURIComponent(e.message));
  }
});

// ── RESEND VERIFICATION ──────────────────────
router.post('/resend-verification', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.redirect('/login?error=' + encodeURIComponent('Email diperlukan'));
  try {
    const user = await db.findUser({ email });
    if (!user) return res.redirect('/login?success=' + encodeURIComponent('Jika email terdaftar, link verifikasi telah dikirim.'));
    if (user.email_verified) return res.redirect('/login?success=' + encodeURIComponent('Email sudah terverifikasi, silakan login.'));
    const token = generateToken();
    await db.updateUser(user.id, {
      verify_token: token,
      verify_token_expires: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
    });
    await sendVerificationEmail(user.email, token, user.username);
    res.redirect('/login?success=' + encodeURIComponent('Link verifikasi baru telah dikirim. Cek inbox (dan folder Spam/Junk).'));
  } catch (e) {
    res.redirect('/login?error=' + encodeURIComponent(e.message));
  }
});

// ── REGISTER ─────────────────────────────────
router.get('/register', (req, res) => {
  if (req.session?.user) return res.redirect('/dashboard');
  res.render('register', { error: null, success: null });
});

router.post('/register', async (req, res) => {
  const { username, email, password, confirm_password } = req.body;
  if (!username || !email || !password) return res.render('register', { error: 'Semua field wajib diisi', success: null });
  if (password !== confirm_password) return res.render('register', { error: 'Password tidak cocok', success: null });
  if (password.length < 6) return res.render('register', { error: 'Password minimal 6 karakter', success: null });
  if (!/^[a-zA-Z0-9_]+$/.test(username)) return res.render('register', { error: 'Username hanya boleh huruf, angka, dan underscore', success: null });
  try {
    const user = await createUser({ username, email, password, role: 'regular', email_verified: false });
    await sendVerificationEmail(user.email, user.verify_token, user.username);
    res.render('register', {
      error: null,
      success: `Registrasi berhasil! Link verifikasi telah dikirim ke <strong>${email}</strong>. Cek inbox dan folder <strong>Spam/Junk</strong>. Kamu harus verifikasi email sebelum bisa login.`
    });
  } catch (e) {
    res.render('register', { error: e.message, success: null });
  }
});

// ── VERIFY EMAIL ─────────────────────────────
router.get('/verify-email/:token', async (req, res) => {
  const { token } = req.params;
  try {
    const user = await db.findUser({ verify_token: token });
    if (!user) return res.render('verify-email', { success: false, message: 'Link verifikasi tidak valid atau sudah digunakan.' });
    if (new Date(user.verify_token_expires) < new Date()) {
      return res.render('verify-email', { success: false, message: 'Link verifikasi sudah kadaluarsa. Silakan minta link baru.' });
    }
    await db.updateUser(user.id, { email_verified: true, verify_token: null, verify_token_expires: null });
    res.render('verify-email', { success: true, message: 'Email berhasil diverifikasi! Kamu sekarang bisa login.' });
  } catch (e) {
    res.render('verify-email', { success: false, message: 'Terjadi kesalahan: ' + e.message });
  }
});

// ── FORGOT PASSWORD ──────────────────────────
router.get('/forgot-password', (req, res) => {
  res.render('forgot-password', { error: null, success: null });
});

router.post('/forgot-password', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.render('forgot-password', { error: 'Email diperlukan', success: null });
  try {
    const user = await db.findUser({ email });
    if (!user) {
      return res.render('forgot-password', {
        error: null,
        success: 'Jika email terdaftar, link reset password telah dikirim. Cek inbox dan folder Spam/Junk.'
      });
    }
    const token = generateToken();
    await db.updateUser(user.id, {
      reset_token: token,
      reset_token_expires: new Date(Date.now() + 60 * 60 * 1000).toISOString()
    });
    await sendPasswordResetEmail(user.email, token, user.username);
    res.render('forgot-password', {
      error: null,
      success: 'Link reset password telah dikirim ke email kamu. Cek inbox dan folder <strong>Spam/Junk</strong>.'
    });
  } catch (e) {
    res.render('forgot-password', { error: e.message, success: null });
  }
});

// ── RESET PASSWORD ───────────────────────────
router.get('/reset-password/:token', async (req, res) => {
  const { token } = req.params;
  const user = await db.findUser({ reset_token: token });
  if (!user || new Date(user.reset_token_expires) < new Date()) {
    return res.render('reset-password', { token, error: 'Link tidak valid atau sudah kadaluarsa.', success: null, valid: false });
  }
  res.render('reset-password', { token, error: null, success: null, valid: true });
});

router.post('/reset-password/:token', async (req, res) => {
  const { token } = req.params;
  const { password, confirm_password } = req.body;
  if (!password || password.length < 6) {
    return res.render('reset-password', { token, error: 'Password minimal 6 karakter', success: null, valid: true });
  }
  if (password !== confirm_password) {
    return res.render('reset-password', { token, error: 'Password tidak cocok', success: null, valid: true });
  }
  try {
    const user = await db.findUser({ reset_token: token });
    if (!user || new Date(user.reset_token_expires) < new Date()) {
      return res.render('reset-password', { token, error: 'Link tidak valid atau sudah kadaluarsa.', success: null, valid: false });
    }
    const hashed = await hashPassword(password);
    await db.updateUser(user.id, { password: hashed, reset_token: null, reset_token_expires: null });
    res.redirect('/login?success=' + encodeURIComponent('Password berhasil direset. Silakan login dengan password baru.'));
  } catch (e) {
    res.render('reset-password', { token, error: e.message, success: null, valid: true });
  }
});

// ── CHANGE PASSWORD (logged-in) ──────────────
router.post('/user/change-password', async (req, res) => {
  if (!req.session?.user) return res.redirect('/login');
  const { current_password, new_password, confirm_new_password } = req.body;
  if (!current_password || !new_password) {
    return res.redirect('/dashboard?error=' + encodeURIComponent('Semua field wajib diisi') + '#profil');
  }
  if (new_password.length < 6) {
    return res.redirect('/dashboard?error=' + encodeURIComponent('Password baru minimal 6 karakter') + '#profil');
  }
  if (new_password !== confirm_new_password) {
    return res.redirect('/dashboard?error=' + encodeURIComponent('Password baru tidak cocok') + '#profil');
  }
  try {
    const user = await db.findUser({ id: req.session.user.id });
    if (!user || !user.password) {
      return res.redirect('/dashboard?error=' + encodeURIComponent('Tidak bisa ganti password akun Google') + '#profil');
    }
    const valid = await checkPassword(current_password, user.password);
    if (!valid) {
      return res.redirect('/dashboard?error=' + encodeURIComponent('Password lama salah') + '#profil');
    }
    const hashed = await hashPassword(new_password);
    await db.updateUser(user.id, { password: hashed });
    const { password: _, ...safeUser } = await db.findUser({ id: user.id });
    req.session.user = safeUser;
    res.redirect('/dashboard?success=' + encodeURIComponent('Password berhasil diubah') + '#profil');
  } catch (e) {
    res.redirect('/dashboard?error=' + encodeURIComponent(e.message) + '#profil');
  }
});

// ── TOGGLE 2FA ────────────────────────────────
router.post('/user/toggle-2fa', async (req, res) => {
  if (!req.session?.user) return res.redirect('/login');
  try {
    const user = await db.findUser({ id: req.session.user.id });
    const newState = !user.twofa_enabled;
    await db.updateUser(user.id, { twofa_enabled: newState });
    const { password: _, ...safeUser } = await db.findUser({ id: user.id });
    req.session.user = safeUser;
    const msg = newState ? '2FA aktif. Kode OTP akan dikirim ke email saat login.' : '2FA dinonaktifkan.';
    res.redirect('/dashboard?success=' + encodeURIComponent(msg) + '#profil');
  } catch (e) {
    res.redirect('/dashboard?error=' + encodeURIComponent(e.message) + '#profil');
  }
});

// ── GOOGLE OAUTH ──────────────────────────────
router.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

router.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/login?error=' + encodeURIComponent('Login Google gagal') }),
  (req, res) => {
    if (!req.user) return res.redirect('/login');
    res.redirect(req.user.role === 'admin' ? '/admin' : '/dashboard');
  }
);

// ── LOGOUT ────────────────────────────────────
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/dashboard');
});

// ── MARK ANNOUNCEMENT READ ───────────────────
router.post('/user/mark-announcement-read', async (req, res) => {
  if (!req.session?.user) return res.json({ ok: false });
  const { id } = req.body;
  try {
    const user = await db.findUser({ id: req.session.user.id });
    const list = Array.isArray(user.read_announcements) ? user.read_announcements : [];
    if (!list.includes(id)) {
      await db.updateUser(user.id, { read_announcements: [...list, id] });
      const { password: _, ...safeUser } = await db.findUser({ id: user.id });
      req.session.user = safeUser;
    }
    res.json({ ok: true });
  } catch { res.json({ ok: false }); }
});

module.exports = router;
