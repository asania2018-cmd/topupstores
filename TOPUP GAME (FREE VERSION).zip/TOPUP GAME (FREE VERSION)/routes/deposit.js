'use strict';
const express    = require('express');
const router     = express.Router();
const db         = require('../lib/github-db');
const { apikeyMiddleware, authMiddleware } = require('../lib/auth');
const { getConfig }    = require('../lib/pricing');
const { withLock }     = require('../lib/mutex');
const { createQris, checkQrisStatus, cancelQris } = require('../lib/payqris');

// ══════════════════════════════════════════════════════════════════════════════
// Routes
// ══════════════════════════════════════════════════════════════════════════════
router.post('/api/deposit/create',  apikeyMiddleware,  async (req, res) => handleCreateDeposit(req, res, req.apiUser));
router.post('/api/deposit/check',   apikeyMiddleware,  async (req, res) => handleCheckDeposit(req, res, req.apiUser));
router.post('/web/deposit/create',  authMiddleware,    async (req, res) => handleCreateDeposit(req, res, req.user));
router.post('/web/deposit/check',   authMiddleware,    async (req, res) => handleCheckDeposit(req, res, req.user));

// ══════════════════════════════════════════════════════════════════════════════
// CREATE DEPOSIT
// ══════════════════════════════════════════════════════════════════════════════
async function handleCreateDeposit(req, res, sessionUser) {
  const cfg        = getConfig();
  const minDeposit = cfg.deposit?.min || 10000;
  const parsedAmt  = parseInt(req.body.amount);

  if (!parsedAmt || parsedAmt < minDeposit) {
    return res.json({ status: false, message: `Minimal deposit Rp${minDeposit.toLocaleString('id-ID')}` });
  }

  try {
    // Kode unik 10–50 untuk identifikasi pembayaran
    const uniqueCode  = Math.floor(Math.random() * 41) + 10;
    const amountToPay = parsedAmt + uniqueCode;

    // Buat QRIS via payqris.web.id
    // trxid internal kita = 'DEP-' + timestamp untuk identifikasi
    const internalTrxid = 'DEP-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase();

    let qrisData;
    try {
      qrisData = await createQris(amountToPay, internalTrxid);
    } catch (qrisErr) {
      return res.json({ status: false, message: 'Gagal generate QRIS: ' + qrisErr.message });
    }

    const deposit = {
      trxid:             internalTrxid,
      payqris_trxid:     qrisData.trxid,       // trxid dari payqris (untuk cek status)
      user_id:           sessionUser.id,
      username:          sessionUser.username,
      amount:            parsedAmt,
      unique_code:       uniqueCode,
      amount_to_pay:     amountToPay,
      status:            'pending',
      qris_image:        qrisData.qris_image,
      expired:           qrisData.expired,
      created_at:        new Date().toISOString(),
    };

    await db.addDeposit(deposit);

    return res.json({
      status: true,
      creator: process.env.SITE_NAME,
      result: {
        trxid:         internalTrxid,
        amount:        parsedAmt,
        unique_code:   uniqueCode,
        amount_to_pay: amountToPay,
        expired:       qrisData.expired,
        qris_image:    qrisData.qris_image,
      },
    });
  } catch (e) {
    return res.json({ status: false, message: e.message });
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// CHECK DEPOSIT — cek status via payqris API + atomic credit
// ══════════════════════════════════════════════════════════════════════════════
async function handleCheckDeposit(req, res, sessionUser) {
  const { trxid } = req.body;
  if (!trxid) return res.json({ status: false, message: 'trxid diperlukan' });

  try {
    // ── 1. Baca deposit ──────────────────────────────────────────────────────
    const { deposits } = await db.getDeposits();
    const deposit = deposits.find(d => d.trxid === trxid);
    if (!deposit) return res.json({ status: false, message: 'Deposit tidak ditemukan' });

    if (deposit.user_id !== sessionUser.id && sessionUser.role !== 'admin') {
      return res.json({ status: false, message: 'Akses ditolak' });
    }

    // ── 2. Status final — langsung return ────────────────────────────────────
    if (deposit.status === 'success') {
      return res.json({ status: true, result: { trxid, status: 'success', amount: deposit.amount, message: 'Deposit berhasil' } });
    }
    if (deposit.status === 'cancelled') {
      return res.json({ status: true, result: { trxid, status: 'cancelled', message: 'Deposit sudah dibatalkan' } });
    }
    if (deposit.status === 'expired') {
      return res.json({ status: true, result: { trxid, status: 'expired', message: 'QRIS sudah kadaluarsa' } });
    }

    // ── 3. Cek expiry lokal ──────────────────────────────────────────────────
    if (deposit.expired && new Date() > new Date(deposit.expired)) {
      await db.updateDeposit(trxid, { status: 'expired' });
      // Batalkan di payqris juga jika ada
      if (deposit.payqris_trxid) cancelQris(deposit.payqris_trxid).catch(() => {});
      return res.json({ status: true, result: { trxid, status: 'expired', message: 'QRIS sudah kadaluarsa' } });
    }

    // ── 4. Cek status via payqris API ────────────────────────────────────────
    if (!deposit.payqris_trxid) {
      return res.json({ status: true, result: { trxid, status: 'pending', amount: deposit.amount, message: 'Menunggu pembayaran...' } });
    }

    let apiStatus;
    try {
      const apiResp = await checkQrisStatus(deposit.payqris_trxid);
      apiStatus = (apiResp.txStatus || '').toLowerCase();
    } catch (apiErr) {
      console.error('[deposit-check] checkQrisStatus error:', apiErr.message);
      return res.json({ status: true, result: { trxid, status: 'pending', amount: deposit.amount, message: 'Menunggu konfirmasi pembayaran...' } });
    }

    if (apiStatus !== 'sukses') {
      return res.json({ status: true, result: { trxid, status: 'pending', amount: deposit.amount, message: 'Menunggu pembayaran...' } });
    }

    // ── 5. ATOMIC CREDIT: lock per trxid — cegah double-credit concurrent ────
    let creditResult;
    try {
      creditResult = await db.creditDepositIfPending(trxid);
    } catch (creditErr) {
      console.error('[deposit-check] creditDepositIfPending error:', creditErr.message);
      return res.json({ status: false, message: 'Gagal memproses deposit: ' + creditErr.message });
    }

    if (!creditResult.credited) {
      const st = creditResult.reason || 'success';
      return res.json({ status: true, result: { trxid, status: st, amount: deposit.amount, message: 'Deposit sudah diproses.' } });
    }

    return res.json({
      status: true,
      result: {
        trxid,
        status:  'success',
        amount:  deposit.amount,
        message: 'Deposit berhasil dikonfirmasi!',
      },
    });

  } catch (e) {
    return res.json({ status: false, message: e.message });
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// CANCEL DEPOSIT (web session)
// ══════════════════════════════════════════════════════════════════════════════
router.post('/web/deposit/cancel', authMiddleware, async (req, res) => {
  const { trxid } = req.body;
  if (!trxid) return res.json({ status: false, message: 'trxid diperlukan' });
  try {
    const { deposits } = await db.getDeposits();
    const deposit = deposits.find(d => d.trxid === trxid);
    if (!deposit)                                                     return res.json({ status: false, message: 'Deposit tidak ditemukan' });
    if (deposit.user_id !== req.user.id && req.user.role !== 'admin') return res.json({ status: false, message: 'Akses ditolak' });
    if (deposit.status !== 'pending')                                 return res.json({ status: false, message: 'Hanya deposit pending yang bisa dibatalkan (status: ' + deposit.status + ')' });
    await db.updateDeposit(trxid, { status: 'cancelled', cancelled_at: new Date().toISOString() });
    if (deposit.payqris_trxid) cancelQris(deposit.payqris_trxid).catch(() => {});
    return res.json({ status: true, message: 'Deposit berhasil dibatalkan' });
  } catch (e) {
    return res.json({ status: false, message: e.message });
  }
});

module.exports = router;
