# Source code web topup by sanzxcode

Platform topup H2H dengan tampilan modern dark navy blue.

## Fitur Baru v2.0
- Dark navy blue theme (Ditusi-style)
- Banner slider di homepage (admin bisa atur via panel)
- Flash Sale section dengan countdown timer
- Produk dipisah per kategori dengan tab filter
- Admin: kelola banner slider (tambah/edit/hapus/toggle)
- Admin: kelola flash sale (tambah/toggle/hapus)
- Admin: update logo produk via URL
- UI mobile-first, responsive penuh
- CSS murni, tanpa framework tambahan

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Salin .env
cp .env.example .env
# Edit .env sesuai konfigurasi

# 3. Jalankan
npm start

# Development (auto-reload)
npm run dev
```

## Akses
- Website: http://localhost:3000
- Admin panel: http://localhost:3000/admin
- API docs: http://localhost:3000/docs

## Stack
- Node.js + Express 4
- EJS + express-ejs-layouts
- JSON file-based DB via GitHub API (github-db)
- OkeConnect API integration
- CSS murni (dark navy theme)
